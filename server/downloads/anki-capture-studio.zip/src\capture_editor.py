"""
Post-Capture Editor Window
Allows user to preview, edit, and adjust captures before sending to Anki
"""
import tkinter as tk
from tkinter import ttk, Canvas
from PIL import Image, ImageTk, ImageDraw
import wave
import numpy as np
import sounddevice as sd
import threading
import os
import time


class WaveformCanvas(Canvas):
    """Canvas widget for drawing audio waveform with trim markers"""
    
    def __init__(self, parent, audio_data, sample_rate, **kwargs):
        super().__init__(parent, **kwargs)
        self.audio_data = audio_data
        self.sample_rate = sample_rate
        self.duration = len(audio_data) / sample_rate if audio_data is not None else 0
        
        # Trim markers (in seconds)
        self.trim_start = 0
        self.trim_end = self.duration
        
        # Playback position (in seconds)
        self.playback_pos = 0
        
        # Dragging state
        self.dragging = None  # 'start', 'end', 'playhead', or None
        self.drag_offset = 0
        
        # Colors
        self.bg_color = '#1e1e2e'
        self.wave_color = '#89b4fa'
        self.trim_color = '#a6e3a1'
        self.playhead_color = '#f38ba8'
        
        # Performance optimization
        self.waveform_cache = None
        self.last_width = 0
        self.pending_redraw = None
        
        self.bind('<Button-1>', self._on_click)
        self.bind('<B1-Motion>', self._on_drag)
        self.bind('<ButtonRelease-1>', self._on_release)
        self.bind('<Configure>', self._on_resize)
        
        # Initial draw after widget is mapped
        self.after(100, self.draw_waveform)
    
    def _on_resize(self, event):
        """Redraw when canvas is resized"""
        self.draw_waveform()
    
    def _time_to_x(self, time_sec):
        """Convert time in seconds to x coordinate"""
        if self.duration == 0:
            return 0
        return int((time_sec / self.duration) * self.winfo_width())
    
    def _x_to_time(self, x):
        """Convert x coordinate to time in seconds"""
        width = self.winfo_width()
        if width == 0:
            return 0
        return (x / width) * self.duration
    
    def _on_click(self, event):
        """Handle mouse click"""
        click_time = self._x_to_time(event.x)
        
        # Check if clicking near trim start marker (within 35 pixels for much easier clicking)
        start_x = self._time_to_x(self.trim_start)
        end_x = self._time_to_x(self.trim_end)
        playhead_x = self._time_to_x(self.playback_pos)
        
        if abs(event.x - start_x) < 35:
            self.dragging = 'start'
            self.drag_offset = event.x - start_x
        elif abs(event.x - end_x) < 35:
            self.dragging = 'end'
            self.drag_offset = event.x - end_x
        elif abs(event.x - playhead_x) < 35:
            self.dragging = 'playhead'
            self.drag_offset = event.x - playhead_x
        else:
            # Click anywhere else moves playhead
            self.playback_pos = max(0, min(click_time, self.duration))
            self.update_display()
    
    def _on_drag(self, event):
        """Handle mouse drag"""
        if self.dragging:
            adjusted_x = event.x - self.drag_offset
            new_time = self._x_to_time(adjusted_x)
            new_time = max(0, min(new_time, self.duration))
            
            if self.dragging == 'start':
                self.trim_start = min(new_time, self.trim_end - 0.1)
            elif self.dragging == 'end':
                self.trim_end = max(new_time, self.trim_start + 0.1)
            elif self.dragging == 'playhead':
                self.playback_pos = new_time
            
            self.update_display()
    
    def _on_release(self, event):
        """Handle mouse release"""
        self.dragging = None
    
    def update_display(self):
        """Schedule waveform redraw on main thread with throttling"""
        try:
            # Cancel pending redraw if exists
            if self.pending_redraw:
                self.after_cancel(self.pending_redraw)
            # Schedule new redraw with small delay to batch updates
            self.pending_redraw = self.after(16, self._do_redraw)  # ~60fps
        except:
            pass
    
    def _do_redraw(self):
        """Actually perform the redraw"""
        self.pending_redraw = None
        self.draw_waveform()
    
    def draw_waveform(self):
        """Draw the waveform visualization with caching"""
        self.delete('all')
        
        width = self.winfo_width()
        height = self.winfo_height()
        
        if width <= 1 or height <= 1:
            return
        
        # Draw background
        self.create_rectangle(0, 0, width, height, fill=self.bg_color, outline='')
        
        if self.audio_data is None or len(self.audio_data) == 0:
            return
        
        # Cache waveform data if width changed
        if self.waveform_cache is None or self.last_width != width:
            self._generate_waveform_cache(width, height)
            self.last_width = width
        
        # Draw cached waveform with current trim colors
        mid_y = height // 2
        for x, (y1, y2) in enumerate(self.waveform_cache):
            if x >= width:
                break
            
            # Dim waveform outside trim range
            time_at_x = self._x_to_time(x)
            if time_at_x < self.trim_start or time_at_x > self.trim_end:
                color = '#45475a'  # Dimmed
            else:
                color = self.wave_color
            
            self.create_line(x, y1, x, y2, fill=color, width=1)
        
        self._draw_markers(width, height)
    
    def _generate_waveform_cache(self, width, height):
        """Generate cached waveform data for faster rendering"""
        samples_per_pixel = max(1, len(self.audio_data) // width)
        
        # Convert stereo to mono if needed
        if len(self.audio_data.shape) > 1:
            audio_mono = np.mean(self.audio_data, axis=1)
        else:
            audio_mono = self.audio_data
        
        mid_y = height // 2
        max_amplitude = height // 2 - 5
        
        self.waveform_cache = []
        for x in range(width):
            start_sample = x * samples_per_pixel
            end_sample = min(start_sample + samples_per_pixel, len(audio_mono))
            
            if start_sample >= len(audio_mono):
                break
            
            # Get min and max for this pixel
            chunk = audio_mono[start_sample:end_sample]
            if len(chunk) > 0:
                min_val = np.min(chunk)
                max_val = np.max(chunk)
                
                y1 = mid_y - int(max_val * max_amplitude)
                y2 = mid_y - int(min_val * max_amplitude)
                self.waveform_cache.append((y1, y2))
    
    def _draw_markers(self, width, height):
        """Draw trim markers and playhead"""
        start_x = self._time_to_x(self.trim_start)
        end_x = self._time_to_x(self.trim_end)
        
        # Draw trim start marker (green) - much larger handles for easier dragging
        start_x = self._time_to_x(self.trim_start)
        self.create_line(start_x, 0, start_x, height, fill='#a6e3a1', width=4)
        # Much larger triangle at top
        self.create_polygon(
            start_x - 22, 0, start_x + 22, 0, start_x, 30,
            fill='#a6e3a1', outline='#1e1e2e', width=3
        )
        # Much larger handle at bottom
        self.create_rectangle(
            start_x - 20, height - 40, start_x + 20, height,
            fill='#a6e3a1', outline='#1e1e2e', width=3
        )
        
        # Draw trim end marker (green) - much larger handles for easier dragging
        end_x = self._time_to_x(self.trim_end)
        self.create_line(end_x, 0, end_x, height, fill='#a6e3a1', width=4)
        # Much larger triangle at bottom
        self.create_polygon(
            end_x - 22, height, end_x + 22, height, end_x, height - 30,
            fill='#a6e3a1', outline='#1e1e2e', width=3
        )
        # Much larger handle at top
        self.create_rectangle(
            end_x - 20, 0, end_x + 20, 40,
            fill='#a6e3a1', outline='#1e1e2e', width=3
        )
        
        # Draw playhead (yellow/white)
        playhead_x = self._time_to_x(self.playback_pos)
        self.create_line(playhead_x, 0, playhead_x, height, fill='#f9e2af', width=2)
        self.create_oval(
            playhead_x - 4, 5, playhead_x + 4, 13,
            fill='#f9e2af', outline=''
        )


class CaptureEditor:
    """Editor window for reviewing and editing captures before sending to Anki"""
    
    def __init__(self, parent, audio_path=None, image_paths=None, gif_path=None,
                 mode_name="", callback=None, gif_speed_ms=100, embedded=False, layout_mode="side",
                 editor_mode_info=None):
        """
        parent: parent window or frame
        audio_path: path to audio file
        image_paths: list of image paths (for screenshots mode) or single path
        gif_path: path to GIF file
        mode_name: name of capture mode (for display)
        callback: function(confirmed, audio_path, media_paths, note_text) called when done
        gif_speed_ms: milliseconds per frame for GIF animation
        embedded: if True, embed in parent frame instead of creating new window
        layout_mode: 'side' or 'bottom' - affects component arrangement in embedded mode
        editor_mode_info: dict with Editor Mode info {captures_list, current_index, on_select, on_delete, on_send}
        """
        self.parent = parent
        self.audio_path = audio_path
        self.image_paths = image_paths if isinstance(image_paths, list) else ([image_paths] if image_paths else [])
        self.gif_path = gif_path
        self.mode_name = mode_name
        self.callback = callback
        self.gif_speed_ms = gif_speed_ms
        self.embedded = embedded
        self.layout_mode = layout_mode
        self.editor_mode_info = editor_mode_info
        
        self.confirmed = False
        self.audio_data = None
        self.sample_rate = None
        self.playing = False
        self.paused = False
        self.pause_position = 0
        self.play_thread = None
        self.waveform_canvas = None
        self.gif_label = None
        self.gif_frames = []
        self.gif_frame_index = 0
        self.animating_gif = False
        
        # Screenshot selection (for multiple screenshots mode)
        self.screenshot_checkboxes = {}  # {path: BooleanVar}
        
        # Load audio if provided
        if audio_path and os.path.exists(audio_path):
            self._load_audio()
        
        # Only create window if not embedded
        if not embedded:
            self._create_window()
        
    def _load_audio(self):
        """Load audio file for preview and editing"""
        try:
            with wave.open(self.audio_path, 'rb') as wf:
                self.sample_rate = wf.getframerate()
                frames = wf.readframes(wf.getnframes())
                self.audio_data = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
                
                # Reshape to stereo if needed
                if wf.getnchannels() == 2:
                    self.audio_data = self.audio_data.reshape(-1, 2)
                    
        except Exception as e:
            print(f"Error loading audio: {e}")
            self.audio_data = None
    
    def _create_embedded_content(self):
        """Create editor content directly in parent frame (embedded mode)"""
        # Colors
        colors = {
            'bg': '#1e1e2e', 'fg': '#cdd6f4', 'accent': '#89b4fa',
            'success': '#a6e3a1', 'error': '#f38ba8', 'card': '#313244',
            'border': '#585b70'
        }
        self.colors = colors
        
        # Use parent directly as main frame
        main_frame = self.parent
        
        # Build the editor UI directly in the parent frame
        self._build_editor_ui(main_frame)
    
    def _create_window(self):
        """Create the editor window UI (non-embedded mode)"""
        self.window = tk.Toplevel(self.parent)
        self.window.title(f"📝 Edit Capture - {self.mode_name}")
        self.window.geometry("1000x800")
        self.window.configure(bg='#1e1e2e')
        self.window.transient(self.parent)
        self.window.grab_set()
        
        # Allow window resizing
        self.window.resizable(True, True)
        self.window.minsize(800, 600)
        
        # Optimize window performance
        try:
            self.window.attributes('-alpha', 0.0)  # Start invisible
        except:
            pass
        
        # Colors
        colors = {
            'bg': '#1e1e2e', 'fg': '#cdd6f4', 'accent': '#89b4fa',
            'success': '#a6e3a1', 'error': '#f38ba8', 'card': '#313244',
            'border': '#585b70'
        }
        self.colors = colors
        
        # Create main container with scrollbar
        container = tk.Frame(self.window, bg=colors['bg'])
        container.pack(fill='both', expand=True)
        
        # Canvas for scrolling
        canvas = tk.Canvas(container, bg=colors['bg'], highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient='vertical', command=canvas.yview)
        
        # Scrollable frame
        scrollable_frame = tk.Frame(canvas, bg=colors['bg'])
        scrollable_frame.bind(
            '<Configure>',
            lambda e: canvas.configure(scrollregion=canvas.bbox('all'))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor='nw', width=980)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Enable mousewheel scrolling
        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except:
                pass
        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)
        
        canvas.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        main_frame = scrollable_frame
        
        # Build the editor UI
        self._build_editor_ui(main_frame)
    
    def _build_editor_ui(self, main_frame):
        """Build the editor UI components in the given frame"""
        colors = self.colors
        
        # Title (only if not embedded)
        if not self.embedded:
            title = tk.Label(
                main_frame,
                text=f"📝 Review & Edit - {self.mode_name}",
                bg=colors['bg'],
                fg=colors['accent'],
                font=('Segoe UI', 14, 'bold')
            )
            title.pack(pady=(10, 10))
        
        # Action Buttons (pack at bottom first if in bottom layout)
        # Only show if callback is provided (not in Editor Mode where main.py handles actions)
        if self.embedded and self.layout_mode == "bottom" and self.callback:
            button_frame = tk.Frame(main_frame, bg=colors['card'])
            button_frame.pack(side='bottom', fill='x', padx=10, pady=(10, 10))
            
            tk.Button(
                button_frame,
                text="✅ Confirm & Send",
                command=self._confirm,
                bg=colors['success'],
                fg='#1e1e2e',
                font=('Segoe UI', 12, 'bold'),
                padx=30,
                pady=10
            ).pack(expand=True, fill='x')
        
        # Layout logic: bottom=horizontal split, side=vertical stack
        if self.embedded and self.layout_mode == "bottom":
            # Create PanedWindow for horizontal split
            content_paned = tk.PanedWindow(main_frame, orient=tk.HORIZONTAL,
                                          bg=colors['card'],
                                          sashwidth=8,
                                          sashrelief=tk.RAISED,
                                          bd=0)
            content_paned.pack(fill='both', expand=True)
            
            # Left panel for audio
            audio_container = tk.Frame(content_paned, bg=colors['card'])
            content_paned.add(audio_container, stretch='always')
            
            # Right panel for media
            media_container = tk.Frame(content_paned, bg=colors['card'])
            content_paned.add(media_container, stretch='always')
            
            # Set initial sash position to 50/50
            main_frame.update_idletasks()
            paned_width = content_paned.winfo_width()
            if paned_width > 1:
                content_paned.sash_place(0, paned_width // 2, 0)
        else:
            # Vertical layout (default)
            audio_container = main_frame
            media_container = main_frame
        
        # Audio Preview Section
        if self.audio_path:
            audio_frame = tk.LabelFrame(
                audio_container,
                text="🎵 Audio Editor",
                bg=colors['card'],
                fg=colors['accent'],
                font=('Segoe UI', 10, 'bold'),
                padx=15,
                pady=15
            )
            if self.embedded and self.layout_mode == "bottom":
                audio_frame.pack(fill='both', expand=True, padx=10, pady=10)
            else:
                audio_frame.pack(fill='x', padx=10, pady=(0, 10))
            
            # Audio info - dynamic time label at top
            if self.audio_data is not None:
                self.time_label = tk.Label(
                    audio_frame,
                    text="",
                    bg=colors['card'],
                    fg=colors['fg'],
                    font=('Segoe UI', 10)
                )
                self.time_label.pack(pady=(0, 10))
                
                # Waveform canvas
                waveform_frame = tk.Frame(audio_frame, bg=colors['card'])
                waveform_frame.pack(fill='x', pady=(0, 10))
                
                tk.Label(
                    waveform_frame,
                    text="🎼 Waveform Timeline (Drag markers to trim, drag playhead to seek)",
                    bg=colors['card'],
                    fg=colors['accent'],
                    font=('Segoe UI', 9, 'bold')
                ).pack(pady=(0, 5))
                
                self.waveform_canvas = WaveformCanvas(
                    waveform_frame,
                    self.audio_data,
                    self.sample_rate,
                    height=150,
                    bg='#1e1e2e',
                    highlightthickness=1,
                    highlightbackground=colors['border']
                )
                self.waveform_canvas.pack(fill='x')
                
                # Update time label periodically (label already created at top)
                self._update_time_label()
            
            # Playback controls
            control_frame = tk.Frame(audio_frame, bg=colors['card'])
            control_frame.pack(fill='x', pady=5)
            
            self.play_btn = tk.Button(
                control_frame,
                text="▶️ Play",
                command=self._play_audio,
                bg=colors['accent'],
                fg='#1e1e2e',
                font=('Segoe UI', 10, 'bold'),
                padx=20,
                pady=5
            )
            self.play_btn.pack(side='left', padx=5)
            
            self.pause_btn = tk.Button(
                control_frame,
                text="⏸️ Pause",
                command=self._pause_audio,
                bg=colors['success'],
                fg='#1e1e2e',
                font=('Segoe UI', 10, 'bold'),
                padx=20,
                pady=5,
                state='disabled'
            )
            self.pause_btn.pack(side='left', padx=5)
            
            self.stop_btn = tk.Button(
                control_frame,
                text="⏹️ Stop",
                command=self._stop_audio,
                bg=colors['error'],
                fg='#1e1e2e',
                font=('Segoe UI', 10, 'bold'),
                padx=20,
                pady=5,
                state='disabled'
            )
            self.stop_btn.pack(side='left', padx=5)
        
        # Image/GIF Preview Section
        if self.image_paths or self.gif_path:
            media_frame = tk.LabelFrame(
                media_container,
                text="🖼️ Media Preview",
                bg=colors['card'],
                fg=colors['accent'],
                font=('Segoe UI', 10, 'bold'),
                padx=10,
                pady=10
            )
            if self.embedded and self.layout_mode == "bottom":
                media_frame.pack(fill='both', expand=True, padx=10, pady=10)
            else:
                media_frame.pack(fill='both', expand=True, padx=10, pady=(0, 10))
            
            # Fixed header for selection count (only for multiple screenshots)
            if len(self.image_paths) > 1 and not self.gif_path:
                self._create_fixed_selection_header(media_frame, self.image_paths, colors)
            
            # Create canvas for image preview
            media_canvas_frame = tk.Frame(media_frame, bg=colors['card'])
            media_canvas_frame.pack(fill='both', expand=True)
            
            media_canvas = tk.Canvas(media_canvas_frame, bg=colors['bg'], highlightthickness=0, height=300)
            media_scrollbar = tk.Scrollbar(media_canvas_frame, orient='vertical', command=media_canvas.yview)
            media_scrollable = tk.Frame(media_canvas, bg=colors['bg'])
            
            media_scrollable.bind(
                '<Configure>',
                lambda e: media_canvas.configure(scrollregion=media_canvas.bbox('all'))
            )
            
            # Create window and store reference for width binding
            canvas_window = media_canvas.create_window((0, 0), window=media_scrollable, anchor='nw')
            media_canvas.configure(yscrollcommand=media_scrollbar.set)
            
            # Make scrollable frame expand to full canvas width
            def on_canvas_configure(event):
                media_canvas.itemconfig(canvas_window, width=event.width)
            media_canvas.bind('<Configure>', on_canvas_configure)
            
            media_canvas.pack(side='left', fill='both', expand=True)
            media_scrollbar.pack(side='right', fill='y')
            
            # Enable mousewheel scrolling only when mouse is over media preview
            def on_media_mousewheel(event):
                media_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            
            def on_media_mousewheel_linux(event):
                if event.num == 4:
                    media_canvas.yview_scroll(-1, "units")
                elif event.num == 5:
                    media_canvas.yview_scroll(1, "units")
            
            def on_enter_media(event):
                media_canvas.bind_all("<MouseWheel>", on_media_mousewheel)
                media_canvas.bind_all("<Button-4>", on_media_mousewheel_linux)
                media_canvas.bind_all("<Button-5>", on_media_mousewheel_linux)
            
            def on_leave_media(event):
                media_canvas.unbind_all("<MouseWheel>")
                media_canvas.unbind_all("<Button-4>")
                media_canvas.unbind_all("<Button-5>")
            
            media_canvas.bind("<Enter>", on_enter_media)
            media_canvas.bind("<Leave>", on_leave_media)
            media_scrollable.bind("<Enter>", on_enter_media)
            media_scrollable.bind("<Leave>", on_leave_media)
            
            # Display images
            if self.gif_path:
                self._display_image(media_scrollable, self.gif_path, colors)
            elif len(self.image_paths) > 1:
                # Multiple screenshots - show with checkboxes (no header, it's fixed above)
                self._display_screenshots_with_checkboxes(media_scrollable, self.image_paths, colors, show_header=False)
            else:
                # Single image
                for img_path in self.image_paths:
                    self._display_image(media_scrollable, img_path, colors)
        
        # Editor Mode: No additional controls here - navigation/delete handled in main.py header
        
        # Action Buttons (only if not already created for bottom layout)
        # Only show if callback is provided (not in Editor Mode where main.py handles actions)
        if not (self.embedded and self.layout_mode == "bottom") and self.callback:
            button_frame = tk.Frame(main_frame, bg=colors['bg'])
            button_frame.pack(fill='x', padx=10, pady=(10, 10))
            
            tk.Button(
                button_frame,
                text="✅ Confirm & Send",
                command=self._confirm,
                bg=colors['success'],
                fg='#1e1e2e',
                font=('Segoe UI', 12, 'bold'),
                padx=30,
                pady=10
            ).pack(expand=True, fill='x')
    
    def _get_time_info(self):
        """Get formatted time information"""
        if self.waveform_canvas:
            playback = self.waveform_canvas.playback_pos
            trim_start = self.waveform_canvas.trim_start
            trim_end = self.waveform_canvas.trim_end
            selected_duration = trim_end - trim_start
            return f"Playback: {playback:.2f}s | Selected Range: {trim_start:.2f}s - {trim_end:.2f}s | Duration: {selected_duration:.2f}s"
        return ""
    
    def _update_time_label(self):
        """Update time label periodically"""
        try:
            if hasattr(self, 'time_label') and self.time_label.winfo_exists() and self.waveform_canvas:
                self.time_label.config(text=self._get_time_info())
                # Use parent for after() call - works in both embedded and window mode
                widget = self.window if hasattr(self, 'window') else self.parent
                if widget and widget.winfo_exists():
                    widget.after(100, self._update_time_label)
        except:
            pass  # Widget destroyed, stop updating
    
    def _create_fixed_selection_header(self, parent, image_paths, colors):
        """Create a fixed header showing selection count that doesn't scroll"""
        # Fixed header frame
        header_frame = tk.Frame(parent, bg=colors['card'])
        header_frame.pack(fill='x', pady=(0, 5))
        
        # Title
        tk.Label(
            header_frame,
            text="Select Screenshots to Include",
            bg=colors['card'],
            fg=colors['accent'],
            font=('Segoe UI', 12, 'bold')
        ).pack(side='left', padx=(5, 15))
        
        # Selected count label with better styling
        count_container = tk.Frame(header_frame, bg=colors['bg'], relief=tk.RAISED, bd=2)
        count_container.pack(side='left')
        
        self.selected_count_label = tk.Label(
            count_container,
            text=f"0 selected out of {len(image_paths)} total",
            bg=colors['bg'],
            fg=colors['error'],
            font=('Segoe UI', 11, 'bold'),
            padx=15,
            pady=5
        )
        self.selected_count_label.pack()
        
        # Zoom controls (+ and - buttons)
        zoom_frame = tk.Frame(header_frame, bg=colors['card'])
        zoom_frame.pack(side='right', padx=(0, 10))
        
        tk.Label(
            zoom_frame,
            text="Size:",
            bg=colors['card'],
            fg=colors['fg'],
            font=('Segoe UI', 10)
        ).pack(side='left', padx=(0, 5))
        
        # Minus button
        minus_btn = tk.Button(
            zoom_frame,
            text="−",
            command=self._decrease_thumbnail_size,
            bg=colors['accent'],
            fg='#1e1e2e',
            font=('Segoe UI', 12, 'bold'),
            width=3,
            cursor='hand2'
        )
        minus_btn.pack(side='left', padx=2)
        
        # Plus button
        plus_btn = tk.Button(
            zoom_frame,
            text="+",
            command=self._increase_thumbnail_size,
            bg=colors['accent'],
            fg='#1e1e2e',
            font=('Segoe UI', 12, 'bold'),
            width=3,
            cursor='hand2'
        )
        plus_btn.pack(side='left', padx=2)
    
    def _increase_thumbnail_size(self):
        """Increase thumbnail size and refresh display"""
        if self.thumbnail_columns > 1:
            self.thumbnail_columns -= 1
            self._refresh_screenshots()
    
    def _decrease_thumbnail_size(self):
        """Decrease thumbnail size and refresh display"""
        if self.thumbnail_columns < 4:
            self.thumbnail_columns += 1
            self._refresh_screenshots()
    
    def _refresh_screenshots(self):
        """Refresh the screenshot grid with current settings"""
        if hasattr(self, '_screenshot_grid_frame') and self._screenshot_grid_frame.winfo_exists():
            # Save current selection state
            selection_state = {path: var.get() for path, var in self.screenshot_checkboxes.items()}
            
            # Clear grid
            for widget in self._screenshot_grid_frame.winfo_children():
                widget.destroy()
            
            # Rebuild with saved selection
            self._build_screenshot_grid(
                self._screenshot_grid_frame,
                self._current_image_paths,
                self._current_colors,
                selection_state
            )
    
    def _display_screenshots_with_checkboxes(self, parent, image_paths, colors, show_header=True):
        """Display multiple screenshots with checkboxes for selection"""
        if not image_paths:
            return

        # Store references for refresh
        self._current_image_paths = image_paths
        self._current_colors = colors
        
        # Initialize thumbnail columns (1 = largest, 4 = smallest)
        if not hasattr(self, 'thumbnail_columns'):
            self.thumbnail_columns = 2  # Default: 2 columns

        # Reset selection state for this render (prevents stale vars from previous captures)
        self.screenshot_checkboxes = {}
        
        # Title and count display (only if show_header is True - for backward compatibility)
        if show_header:
            title_frame = tk.Frame(parent, bg=colors['bg'])
            title_frame.pack(pady=(10, 15), fill='x', padx=10)
            
            tk.Label(
                title_frame,
                text="Select Screenshots to Include",
                bg=colors['bg'],
                fg=colors['accent'],
                font=('Segoe UI', 14, 'bold')
            ).pack(side='left')
            
            # Selected count label with better styling
            count_container = tk.Frame(title_frame, bg=colors['card'], relief=tk.RAISED, bd=2)
            count_container.pack(side='left', padx=(20, 0))
            
            self.selected_count_label = tk.Label(
                count_container,
                text=f"0 selected out of {len(image_paths)} total",
                bg=colors['card'],
                fg=colors['accent'],
                font=('Segoe UI', 11, 'bold'),
                padx=15,
                pady=5
            )
            self.selected_count_label.pack()
        
        # Create grid container and store reference
        grid_frame = tk.Frame(parent, bg=colors['bg'])
        grid_frame.pack(fill='both', expand=True, padx=5, pady=5)
        self._screenshot_grid_frame = grid_frame
        
        # Build the grid
        self._build_screenshot_grid(grid_frame, image_paths, colors)
    
    def _build_screenshot_grid(self, grid_frame, image_paths, colors, selection_state=None):
        """Build the screenshot grid with current column settings"""
        columns = self.thumbnail_columns
        
        # Configure grid columns to expand equally
        for col in range(columns):
            grid_frame.columnconfigure(col, weight=1)
        
        # Function to update count with color coding
        def update_count():
            selected = sum(1 for var in self.screenshot_checkboxes.values() if var.get())
            total = len(self.screenshot_checkboxes)
            if hasattr(self, 'selected_count_label') and self.selected_count_label.winfo_exists():
                self.selected_count_label.config(
                    text=f"{selected} selected out of {total} total",
                    fg=colors['success'] if selected > 0 else colors['error']
                )
        
        # Reset checkboxes for fresh build
        self.screenshot_checkboxes = {}
        
        # Display each screenshot in grid
        for i, img_path in enumerate(image_paths):
            try:
                row = i // columns
                col = i % columns
                
                # Frame for each screenshot - use sticky to fill cell
                screenshot_frame = tk.Frame(
                    grid_frame,
                    bg=colors['card'],
                    relief=tk.RAISED,
                    bd=2,
                    highlightthickness=3,
                    highlightbackground=colors['border'],
                    highlightcolor=colors['border']
                )
                screenshot_frame.grid(row=row, column=col, padx=3, pady=3, sticky='nsew')
                
                # Configure row to expand
                grid_frame.rowconfigure(row, weight=1)

                # Selection state (restore if provided, otherwise default False)
                initial_value = selection_state.get(img_path, False) if selection_state else False
                var = tk.BooleanVar(value=initial_value)
                self.screenshot_checkboxes[img_path] = var
                
                # Image preview - calculate size based on columns and available width
                img = Image.open(img_path)
                
                # Get available width from grid frame (or use fallback)
                grid_frame.update_idletasks()
                available_width = grid_frame.winfo_width()
                if available_width < 100:  # Not yet rendered, use parent width
                    available_width = 1200  # Fallback for initial render
                
                # Calculate per-column width (subtract padding)
                padding_per_cell = 20  # padx + border + margins
                cell_width = (available_width // columns) - padding_per_cell
                cell_width = max(cell_width, 150)  # Minimum size
                
                # Resize to fit cell width while maintaining aspect ratio
                ratio = cell_width / img.width
                new_width = int(img.width * ratio)
                new_height = int(img.height * ratio)
                img_resized = img.resize((new_width, new_height), Image.LANCZOS)
                
                photo = ImageTk.PhotoImage(img_resized)
                
                img_label = tk.Label(screenshot_frame, image=photo, bg=colors['card'])
                img_label.image = photo  # Keep reference
                img_label.pack(pady=3, padx=3, fill='both', expand=True)
                
                # Image info (shortened for grid)
                info = f"{i+1}. {new_width}x{new_height}"
                info_label = tk.Label(
                    screenshot_frame,
                    text=info,
                    bg=colors['card'],
                    fg=colors['fg'],
                    font=('Segoe UI', 8)
                )
                info_label.pack(pady=(0, 3))

                def update_visual_state(_var=var, _frame=screenshot_frame, _img=img_label, _info=info_label):
                    selected = bool(_var.get())
                    # Selected = green, Unselected = gray (neutral)
                    border = colors['success'] if selected else colors['border']
                    bg = colors['success'] if selected else colors['card']
                    fg = colors['accent'] if selected else colors['fg']
                    _frame.config(bg=bg, highlightbackground=border, highlightcolor=border)
                    _img.config(bg=bg)
                    _info.config(bg=bg, fg=fg)

                def toggle_selection(event=None, _var=var, _update_visual_state=update_visual_state):
                    _var.set(not _var.get())
                    update_count()
                    _update_visual_state()

                # Make the entire container clickable (frame, image, info text)
                for w in (screenshot_frame, img_label, info_label):
                    w.bind("<Button-1>", lambda e, _toggle=toggle_selection: _toggle(e))
                    w.config(cursor='hand2')

                update_visual_state()
                
            except Exception as e:
                print(f"Error loading screenshot {img_path}: {e}")

        # Ensure label color/text reflect the initial state
        update_count()
    
    def _display_image(self, parent, image_path, colors):
        """Display an image in the preview"""
        try:
            img = Image.open(image_path)
            
            # Check if it's a GIF
            is_gif = image_path.lower().endswith('.gif')
            
            if is_gif:
                # Load all GIF frames
                self.gif_frames = []
                try:
                    while True:
                        # Resize frame if needed
                        frame = img.copy()
                        max_width = 900
                        if frame.width > max_width:
                            ratio = max_width / frame.width
                            new_height = int(frame.height * ratio)
                            frame = frame.resize((max_width, new_height), Image.LANCZOS)
                        
                        # Convert to PhotoImage
                        photo = ImageTk.PhotoImage(frame)
                        self.gif_frames.append(photo)
                        
                        img.seek(img.tell() + 1)
                except EOFError:
                    pass  # End of frames
                
                if self.gif_frames:
                    # Create label for GIF
                    self.gif_label = tk.Label(parent, bg=colors['bg'])
                    self.gif_label.pack(pady=5)
                    
                    # Start animation with delay to avoid initial lag
                    self.gif_frame_index = 0
                    self.animating_gif = True
                    widget = self.window if hasattr(self, 'window') else self.parent
                    widget.after(100, self._animate_gif)
                    
                    # Image info
                    info = f"{os.path.basename(image_path)} - Animated GIF ({len(self.gif_frames)} frames)"
                    tk.Label(
                        parent,
                        text=info,
                        bg=colors['bg'],
                        fg=colors['fg'],
                        font=('Segoe UI', 8)
                    ).pack(pady=(0, 10))
            else:
                # Static image
                # Resize if too large
                max_width = 900
                if img.width > max_width:
                    ratio = max_width / img.width
                    new_height = int(img.height * ratio)
                    img = img.resize((max_width, new_height), Image.LANCZOS)
                
                photo = ImageTk.PhotoImage(img)
                
                label = tk.Label(parent, image=photo, bg=colors['bg'])
                label.image = photo  # Keep reference
                label.pack(pady=5)
                
                # Image info
                info = f"{os.path.basename(image_path)} - {img.width}x{img.height}"
                tk.Label(
                    parent,
                    text=info,
                    bg=colors['bg'],
                    fg=colors['fg'],
                    font=('Segoe UI', 8)
                ).pack(pady=(0, 10))
            
        except Exception as e:
            tk.Label(
                parent,
                text=f"Error loading image: {str(e)}",
                bg=colors['bg'],
                fg=colors['error'],
                font=('Segoe UI', 9)
            ).pack(pady=5)
    
    def _create_editor_mode_controls(self, parent_frame, colors):
        """Create Editor Mode controls: capture list and action buttons"""
        # Create a visible container frame with border
        editor_mode_frame = tk.LabelFrame(
            parent_frame,
            text="📋 Capture List (Editor Mode)",
            bg=colors['card'],
            fg=colors['accent'],
            font=('Segoe UI', 10, 'bold'),
            padx=15,
            pady=10
        )
        editor_mode_frame.pack(fill='x', padx=10, pady=(10, 10))
        
        # Capture list frame
        list_frame = tk.Frame(editor_mode_frame, bg=colors['card'])
        list_frame.pack(fill='x', pady=(0, 10))
        
        # Capture dropdown/listbox
        captures = self.editor_mode_info.get('captures_list', [])
        current_idx = self.editor_mode_info.get('current_index', 0)
        
        # Create list items for dropdown
        list_items = []
        for i, cap in enumerate(captures):
            mode = cap.get('mode_name', 'Capture')
            list_items.append(f"{i+1}. {mode}")
        
        if not list_items:
            list_items = ["No captures"]
        
        self.capture_list_var = tk.StringVar(value=list_items[current_idx] if current_idx < len(list_items) else list_items[0])
        
        # Dropdown for capture selection
        from tkinter import ttk
        self.capture_dropdown = ttk.Combobox(
            list_frame,
            textvariable=self.capture_list_var,
            values=list_items,
            state='readonly',
            width=35,
            font=('Segoe UI', 10)
        )
        self.capture_dropdown.pack(side='left', padx=(0, 15))
        self.capture_dropdown.bind('<<ComboboxSelected>>', self._on_capture_selected)
        
        # Capture count label
        total = len(captures)
        self.capture_count_label = tk.Label(
            list_frame,
            text=f"{current_idx + 1} / {total}" if total > 0 else "0 / 0",
            bg=colors['card'],
            fg=colors['accent'],
            font=('Segoe UI', 12, 'bold')
        )
        self.capture_count_label.pack(side='left', padx=(0, 15))
        
        # Action buttons frame
        action_frame = tk.Frame(editor_mode_frame, bg=colors['card'])
        action_frame.pack(fill='x', pady=(5, 0))
        
        # Send button
        self.send_btn = tk.Button(
            action_frame,
            text="✅ Confirm & Send",
            command=self._on_send_to_anki,
            bg=colors['success'],
            fg='#1e1e2e',
            font=('Segoe UI', 11, 'bold'),
            padx=20,
            pady=8
        )
        self.send_btn.pack(side='left', padx=(0, 15))
        
        # Delete button
        self.delete_btn = tk.Button(
            action_frame,
            text="🗑️ Delete",
            command=self._on_delete_capture,
            bg=colors['error'],
            fg='#1e1e2e',
            font=('Segoe UI', 11, 'bold'),
            padx=20,
            pady=8
        )
        self.delete_btn.pack(side='left')
    
    def _on_capture_selected(self, event=None):
        """Handle capture selection from dropdown"""
        if not self.editor_mode_info:
            return
        
        selection = self.capture_dropdown.current()
        on_select = self.editor_mode_info.get('on_select')
        if on_select and selection >= 0:
            on_select(selection)
    
    def _on_send_to_anki(self):
        """Handle Confirm & Send button click"""
        if not self.editor_mode_info:
            return
        
        on_send = self.editor_mode_info.get('on_send')
        if on_send:
            on_send()
    
    def _on_delete_capture(self):
        """Handle Delete button click"""
        if not self.editor_mode_info:
            return
        
        on_delete = self.editor_mode_info.get('on_delete')
        if on_delete:
            on_delete()
    
    def _animate_gif(self):
        """Animate GIF frames"""
        if not self.animating_gif or not self.gif_frames or not self.gif_label:
            return
        
        try:
            # Update frame
            self.gif_label.config(image=self.gif_frames[self.gif_frame_index])
            self.gif_frame_index = (self.gif_frame_index + 1) % len(self.gif_frames)
            
            # Schedule next frame using the gif_speed_ms setting
            widget = self.window if hasattr(self, 'window') else self.parent
            widget.after(self.gif_speed_ms, self._animate_gif)
        except:
            self.animating_gif = False
    
    def _play_audio(self):
        """Play audio preview from current playhead position"""
        if self.audio_data is None:
            return
        
        if self.paused:
            # Resume from pause
            self.paused = False
            self.playing = True
            self.play_btn.config(state='disabled', text="▶️ Play")
            self.pause_btn.config(state='normal')
            self.stop_btn.config(state='normal')
            
            # Continue playback thread
            self.play_thread = threading.Thread(target=self._play_thread_func, daemon=True)
            self.play_thread.start()
            return
        
        if self.playing:
            return
        
        self.playing = True
        self.paused = False
        self.play_btn.config(state='disabled')
        self.pause_btn.config(state='normal')
        self.stop_btn.config(state='normal')
        
        self.play_thread = threading.Thread(target=self._play_thread_func, daemon=True)
        self.play_thread.start()
    
    def _play_thread_func(self):
        """Playback thread function"""
        try:
            # Get current positions
            start_time = self.waveform_canvas.playback_pos
            end_time = self.waveform_canvas.trim_end
            
            if start_time >= end_time:
                # Already at end, reset to start
                start_time = self.waveform_canvas.trim_start
                self.waveform_canvas.playback_pos = start_time
            
            # Calculate sample indices
            start_idx = int(start_time * self.sample_rate)
            end_idx = int(end_time * self.sample_rate)
            
            # Get audio to play
            audio_to_play = self.audio_data[start_idx:end_idx]
            
            # Play
            sd.play(audio_to_play, self.sample_rate)
            
            # Update playhead during playback with optimized timing
            start_play_time = time.time()
            last_update = 0
            while sd.get_stream().active and self.playing and not self.paused:
                elapsed = time.time() - start_play_time
                new_pos = min(start_time + elapsed, end_time)
                self.waveform_canvas.playback_pos = new_pos
                
                # Throttle updates to ~30fps for smoother performance
                if elapsed - last_update > 0.033:
                    self.waveform_canvas.update_display()
                    last_update = elapsed
                
                time.sleep(0.033)  # ~30fps
            
            if self.paused:
                sd.stop()
                return
            
            sd.wait()
            
        except Exception as e:
            print(f"Playback error: {e}")
            import traceback
            traceback.print_exc()
        finally:
            if not self.paused:
                self.playing = False
                try:
                    self.play_btn.config(state='normal')
                    self.pause_btn.config(state='disabled')
                    self.stop_btn.config(state='disabled')
                except:
                    pass
    
    def _pause_audio(self):
        """Pause audio playback"""
        if self.playing and not self.paused:
            self.paused = True
            sd.stop()
            self.play_btn.config(state='normal', text="▶️ Resume")
            self.pause_btn.config(state='disabled')
    
    def _stop_audio(self):
        """Stop audio playback"""
        if self.playing or self.paused:
            self.playing = False
            self.paused = False
            sd.stop()
            self.play_btn.config(state='normal', text="▶️ Play")
            self.pause_btn.config(state='disabled')
            self.stop_btn.config(state='disabled')
            # Reset playhead to trim start
            if self.waveform_canvas:
                self.waveform_canvas.playback_pos = self.waveform_canvas.trim_start
                self.waveform_canvas.update_display()
    
    def _apply_audio_trim(self):
        """Apply trim to audio file and save"""
        if self.audio_data is None or self.audio_path is None or not self.waveform_canvas:
            return self.audio_path
        
        try:
            # Get start and end positions from waveform canvas
            start_time = self.waveform_canvas.trim_start
            end_time = self.waveform_canvas.trim_end
            
            duration = len(self.audio_data) / self.sample_rate
            
            # If selecting full range, return original
            if start_time == 0 and end_time >= duration - 0.01:
                return self.audio_path
            
            # Calculate sample indices
            start_idx = int(start_time * self.sample_rate)
            end_idx = int(end_time * self.sample_rate)
            
            # Get trimmed audio (selected range)
            trimmed_audio = self.audio_data[start_idx:end_idx]
            
            # Save trimmed audio
            base, ext = os.path.splitext(self.audio_path)
            trimmed_path = f"{base}_trimmed{ext}"
            
            # Convert back to int16
            audio_int16 = (trimmed_audio * 32767).astype(np.int16)
            
            with wave.open(trimmed_path, 'wb') as wf:
                wf.setnchannels(2 if len(audio_int16.shape) > 1 else 1)
                wf.setsampwidth(2)
                wf.setframerate(self.sample_rate)
                wf.writeframes(audio_int16.tobytes())
            
            print(f"Audio trimmed: {start_time:.2f}s to {end_time:.2f}s, saved to {trimmed_path}")
            return trimmed_path
            
        except Exception as e:
            print(f"Error trimming audio: {e}")
            import traceback
            traceback.print_exc()
            return self.audio_path
    
    def _confirm(self):
        """Confirm and send"""
        self._stop_audio()
        self.animating_gif = False
        
        # Apply audio trim if needed
        final_audio_path = self._apply_audio_trim() if self.audio_path else None
        
        # Determine media paths
        if self.gif_path:
            media_paths = [self.gif_path]
        elif self.screenshot_checkboxes:
            # Filter only checked screenshots
            media_paths = [path for path, var in self.screenshot_checkboxes.items() if var.get()]
            if not media_paths:
                # No screenshots selected
                try:
                    from tkinter import messagebox
                    messagebox.showwarning("No Screenshots Selected", 
                                         "Please select at least one screenshot.")
                except:
                    pass
                return
        else:
            media_paths = self.image_paths
        
        self.confirmed = True
        
        # Only destroy window if not embedded
        if hasattr(self, 'window'):
            self.window.destroy()
        # Don't clear embedded content - keep it visible until next capture
        # elif self.embedded:
        #     for widget in self.parent.winfo_children():
        #         widget.destroy()
        
        if self.callback:
            self.callback(True, final_audio_path, media_paths)
    
    def _cancel(self):
        """Cancel and close"""
        self._stop_audio()
        self.animating_gif = False
        self.confirmed = False
        
        # Only destroy window if not embedded
        if hasattr(self, 'window'):
            self.window.destroy()
        elif self.embedded:
            # In embedded mode, clear the content
            for widget in self.parent.winfo_children():
                widget.destroy()
        
        if self.callback:
            self.callback(False, None, None)
    
    def show(self):
        """Show the editor window and wait"""
        self.window.wait_window()
        return self.confirmed
