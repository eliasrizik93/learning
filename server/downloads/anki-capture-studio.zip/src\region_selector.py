"""
Region Selection Overlay for Screenshot Capture
Allows user to click and drag to select a specific screen region
"""
import tkinter as tk
from PIL import Image, ImageGrab
import mss


class RegionSelector:
    """Overlay window for selecting a screen region"""
    
    def __init__(self, callback):
        """
        callback: function(x, y, width, height) called when region is selected
        """
        self.callback = callback
        self.start_x = None
        self.start_y = None
        self.rect = None
        self.region = None
        
    def select_region(self):
        """Show overlay and let user select region"""
        # Create fullscreen transparent overlay
        self.root = tk.Tk()
        self.root.attributes('-fullscreen', True)
        self.root.attributes('-alpha', 0.3)
        self.root.attributes('-topmost', True)
        self.root.configure(bg='black')
        self.root.config(cursor='cross')
        
        # Create canvas for drawing rectangle
        self.canvas = tk.Canvas(
            self.root,
            bg='black',
            highlightthickness=0,
            cursor='cross'
        )
        self.canvas.pack(fill='both', expand=True)
        
        # Instructions
        label = tk.Label(
            self.root,
            text="Click and drag to select region. Press ESC to cancel.",
            bg='yellow',
            fg='black',
            font=('Arial', 14, 'bold'),
            padx=10,
            pady=5
        )
        label.place(relx=0.5, rely=0.02, anchor='n')
        
        # Bind mouse events
        self.canvas.bind('<Button-1>', self.on_mouse_down)
        self.canvas.bind('<B1-Motion>', self.on_mouse_drag)
        self.canvas.bind('<ButtonRelease-1>', self.on_mouse_up)
        self.root.bind('<Escape>', lambda e: self.cancel())
        
        self.root.mainloop()
        
    def on_mouse_down(self, event):
        """Start drawing rectangle"""
        self.start_x = event.x
        self.start_y = event.y
        
        # Delete previous rectangle if exists
        if self.rect:
            self.canvas.delete(self.rect)
            
    def on_mouse_drag(self, event):
        """Update rectangle as user drags"""
        if self.start_x is None or self.start_y is None:
            return
            
        # Delete previous rectangle
        if self.rect:
            self.canvas.delete(self.rect)
            
        # Draw new rectangle
        self.rect = self.canvas.create_rectangle(
            self.start_x, self.start_y,
            event.x, event.y,
            outline='red',
            width=3,
            fill='red',
            stipple='gray50'
        )
        
    def on_mouse_up(self, event):
        """Finish selection"""
        if self.start_x is None or self.start_y is None:
            return
            
        # Calculate region coordinates
        x1 = min(self.start_x, event.x)
        y1 = min(self.start_y, event.y)
        x2 = max(self.start_x, event.x)
        y2 = max(self.start_y, event.y)
        
        width = x2 - x1
        height = y2 - y1
        
        # Minimum size check
        if width < 50 or height < 50:
            self.cancel()
            return
            
        self.region = (x1, y1, width, height)
        
        # Close overlay and call callback
        self.root.destroy()
        if self.callback:
            self.callback(x1, y1, width, height)
            
    def cancel(self):
        """Cancel selection"""
        self.root.destroy()
        if self.callback:
            self.callback(None, None, None, None)
