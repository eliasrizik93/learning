import os
import time
import threading
from datetime import datetime
from collections import deque
import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import soundcard as sc
import wave
import requests
import mss
import subprocess
import pystray
from pystray import MenuItem as item
import sys
import random
import warnings
import traceback
import logging
from PIL import Image
import genanki
from region_selector import RegionSelector
from capture_editor import CaptureEditor

# 🟢 Suppress annoying soundcard warnings
warnings.filterwarnings("ignore", category=sc.SoundcardRuntimeWarning)
warnings.filterwarnings("ignore", message=".*data discontinuity.*")

# 🟢 Setup paths
SAVE_DIR = os.path.join(os.path.expanduser("~"), "Desktop", "captures")
os.makedirs(SAVE_DIR, exist_ok=True)

# Setup logger with UTF-8 encoding
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

logger.info("=" * 50)
logger.info("Anki Capture Studio Starting...")
logger.info(f"Python version: {sys.version}")
logger.info(f"Working directory: {os.getcwd()}")
logger.info(f"Save directory: {SAVE_DIR}")
logger.info("=" * 50)

# --------------------------------
# Config
# --------------------------------
SAMPLE_RATE = 48000
CHANNELS = 2
CHUNK_SEC = 0.25
DEFAULT_SECONDS = 5

DEFAULT_HOTKEY_AUDIO_TO_IMAGE = "f9"
DEFAULT_HOTKEY_IMAGE_TO_AUDIO = "f10"
DEFAULT_HOTKEY_BOTH_DIRECTIONS = "f11"
DEFAULT_HOTKEY_AUDIO_TO_VIDEO = "f12"
DEFAULT_HOTKEY_AUDIO_TO_SCREENSHOTS = "f8"

DEFAULT_DECK_NAME = "Spanish Listening"

ANKI_MODEL_NAME = "Basic"
DEFAULT_APKG_AUDIO_NAME = "audio_to_image.apkg"
DEFAULT_APKG_IMAGE_NAME = "image_to_audio.apkg"
DEFAULT_APKG_GIF_NAME = "audio_to_gif.apkg"
DEFAULT_APKG_SCREENSHOTS_NAME = "audio_to_screenshots.apkg"
DEFAULT_GIF_SPEED = 500  # milliseconds per frame (500ms = 0.5s per frame)
SETTINGS_FILE = os.path.join(SAVE_DIR, "settings.txt")

# IDs for genanki (can be any fixed integers)
GENANKI_MODEL_ID = 1607392319
GENANKI_DECK_ID = 2059400110


# --------------------------------
# Audio helpers
# --------------------------------
def write_wav_fast(path, data, sr):
    pcm16 = np.int16(np.clip(data, -1, 1) * 32767)
    with wave.open(path, "wb") as f:
        f.setnchannels(data.shape[1])
        f.setsampwidth(2)
        f.setframerate(sr)
        f.writeframes(pcm16.tobytes())


# --------------------------------
# Rolling audio buffer
# --------------------------------
class RollingBuffer:
    def __init__(self, seconds: int, sample_rate: int, channels: int):
        self.sample_rate = sample_rate
        self.channels = channels
        self.max_frames = seconds * sample_rate
        self.buf = deque()
        self.frames = 0
        self.lock = threading.Lock()

    def set_seconds(self, seconds: int):
        with self.lock:
            self.max_frames = max(1, seconds) * self.sample_rate
            self._trim_locked()

    def append(self, chunk: np.ndarray):
        if chunk.ndim == 1:
            chunk = chunk.reshape(-1, self.channels)
        elif chunk.ndim != 2 or chunk.shape[1] != self.channels:
            raise ValueError("Chunk must be (frames, channels)")
        with self.lock:
            self.buf.append(chunk)
            self.frames += chunk.shape[0]
            self._trim_locked()

    def _trim_locked(self):
        while self.frames > self.max_frames and self.buf:
            over = self.frames - self.max_frames
            left = self.buf[0]
            if left.shape[0] <= over:
                self.buf.popleft()
                self.frames -= left.shape[0]
            else:
                self.buf[0] = left[-(left.shape[0] - over):, :]
                self.frames -= over
                break

    def get_last_seconds(self, duration: float) -> np.ndarray:
        """
        Return the last 'duration' seconds of audio ending NOW.
        """
        duration_frames = int(max(0.0, duration) * self.sample_rate)
        with self.lock:
            if self.frames == 0:
                return np.zeros((0, self.channels), dtype=np.float32)
            chunks = list(self.buf)
        all_audio = np.concatenate(chunks, axis=0) if len(chunks) > 1 else chunks[0]
        if duration_frames <= 0:
            return np.zeros((0, self.channels), dtype=np.float32)
        segment = all_audio[-duration_frames:] if all_audio.shape[0] > duration_frames else all_audio
        return segment.astype(np.float32, copy=False)

    def get_recent_frames(self, num_frames: int) -> np.ndarray:
        """Get the most recent N frames from the buffer"""
        with self.lock:
            if self.frames == 0:
                return np.zeros((0, self.channels), dtype=np.float32)
            chunks = list(self.buf)
        data = np.concatenate(chunks, axis=0) if len(chunks) > 1 else chunks[0]
        if data.shape[0] > num_frames:
            data = data[-num_frames:]
        return data.astype(np.float32, copy=False)


# --------------------------------
# Loopback recorder
# --------------------------------
class LoopbackRecorder(threading.Thread):
    def __init__(self, out_device_name, rbuf):
        super().__init__(daemon=True)
        self.rbuf = rbuf
        self.stop_evt = threading.Event()
        self.set_device(out_device_name)

    def set_device(self, out_device_name):
        try:
            self.speaker = next((s for s in sc.all_speakers() if s.name == out_device_name), None)
            if not self.speaker:
                self.speaker = sc.default_speaker()
            self.mic = sc.get_microphone(self.speaker.name, include_loopback=True)
            return True
        except Exception as e:
            print("Device bind error:", e)
            return False

    def run(self):
        frames = int(SAMPLE_RATE * CHUNK_SEC)
        while not self.stop_evt.is_set():
            try:
                with self.mic.recorder(samplerate=SAMPLE_RATE, channels=CHANNELS) as rec:
                    while not self.stop_evt.is_set():
                        data = rec.record(numframes=frames)
                        if data.dtype != np.float32:
                            data = data.astype(np.float32)
                        self.rbuf.append(data)
            except Exception as e:
                print("Loopback error:", e)
                time.sleep(0.2)

    def stop(self):
        self.stop_evt.set()


# --------------------------------
# Rolling screenshot
# --------------------------------
class RollingScreenshot(threading.Thread):
    def __init__(self, interval=0.5, monitor_index=1, max_history_seconds=60):
        super().__init__(daemon=True)
        self.interval = interval
        self.monitor_index = monitor_index
        self.lock = threading.Lock()
        self.stop_evt = threading.Event()
        self.history = deque()
        self.max_history_seconds = max_history_seconds
        # Region capture support
        self.use_region = False
        self.region = None  # (x, y, width, height)

    def set_region(self, x, y, width, height):
        """Set a specific region to capture instead of full monitor"""
        with self.lock:
            self.region = (x, y, width, height)
            self.use_region = True
            logger.info(f"Region capture enabled: x={x}, y={y}, w={width}, h={height}")

    def clear_region(self):
        """Clear region and capture full monitor"""
        with self.lock:
            self.use_region = False
            self.region = None
            logger.info("Region capture disabled - capturing full monitor")

    def run(self):
        while not self.stop_evt.is_set():
            try:
                now = time.time()
                with mss.mss() as sct:
                    monitors = sct.monitors
                    idx = min(max(self.monitor_index, 1), len(monitors) - 1)
                    
                    # Capture region or full monitor
                    if self.use_region and self.region:
                        x, y, width, height = self.region
                        capture_area = {"left": x, "top": y, "width": width, "height": height}
                        frame = sct.grab(capture_area)
                    else:
                        frame = sct.grab(monitors[idx])
                    
                    img = Image.frombytes("RGB", frame.size, frame.rgb)
                with self.lock:
                    self.history.append((now, img.copy()))
                    self._trim_locked(now)
            except Exception as e:
                print("Screenshot error:", e)
            time.sleep(self.interval)

    def _trim_locked(self, now_ts=None):
        if now_ts is None:
            now_ts = time.time()
        min_ts = now_ts - self.max_history_seconds
        while self.history and self.history[0][0] < min_ts:
            self.history.popleft()

    def get_at_time(self, target_ts: float):
        """Get screenshot closest to target_ts"""
        with self.lock:
            if not self.history:
                return None

            closest_img = None
            min_diff = float('inf')

            for ts, img in self.history:
                diff = abs(ts - target_ts)
                if diff < min_diff:
                    min_diff = diff
                    closest_img = img

            logger.info(f"Screenshot: requested time={target_ts:.3f}, found closest at diff={min_diff:.3f}s")
            return closest_img.copy() if closest_img else None

    def get_frames_for_duration(self, duration_seconds: float):
        """Get all frames for the last N seconds to create a GIF"""
        with self.lock:
            if not self.history:
                return []
            
            now = time.time()
            start_time = now - duration_seconds
            
            # Get all frames within the time range
            frames = []
            for ts, img in self.history:
                if ts >= start_time:
                    frames.append(img.copy())
            
            logger.info(f"Retrieved {len(frames)} frames for {duration_seconds}s GIF")
            return frames

    def stop(self):
        self.stop_evt.set()


# --------------------------------
# GIF creation helper
# --------------------------------
def create_gif_from_frames(frames, duration_seconds, gif_speed_ms=None):
    """
    Create a GIF from a list of PIL Image frames.
    Returns the path to the saved GIF file.
    gif_speed_ms: milliseconds per frame (if None, auto-calculate from duration)
    """
    try:
        if not frames or len(frames) == 0:
            logger.error("No frames provided for GIF creation")
            return None
        
        logger.info(f"Creating GIF from {len(frames)} frames")
        
        # Create output filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        gif_path = os.path.join(SAVE_DIR, f"gif_{timestamp}.gif")
        
        # Use custom speed if provided, otherwise auto-calculate
        if gif_speed_ms is not None:
            frame_duration_ms = gif_speed_ms
            logger.info(f"Using custom GIF speed: {frame_duration_ms}ms per frame")
        else:
            # Calculate frame duration in milliseconds
            # duration_seconds / number of frames = time per frame
            frame_duration_ms = int((duration_seconds / len(frames)) * 1000)
            # Minimum 50ms per frame (20 FPS max) for smooth playback
            frame_duration_ms = max(50, frame_duration_ms)
        
        # Resize frames if they're too large (for smaller file size)
        max_width = 800
        resized_frames = []
        for frame in frames:
            if frame.width > max_width:
                ratio = max_width / frame.width
                new_height = int(frame.height * ratio)
                frame = frame.resize((max_width, new_height), Image.LANCZOS)
            resized_frames.append(frame)
        
        # Save as GIF with optimization
        resized_frames[0].save(
            gif_path,
            save_all=True,
            append_images=resized_frames[1:],
            duration=frame_duration_ms,
            loop=0,  # Loop forever
            optimize=True
        )
        
        file_size_mb = os.path.getsize(gif_path) / (1024 * 1024)
        logger.info(f"GIF created: {gif_path} ({file_size_mb:.2f} MB, {len(frames)} frames)")
        return gif_path
        
    except Exception as e:
        logger.error(f"GIF creation failed: {e}", exc_info=True)
        return None


# --------------------------------
# Anki helpers
# --------------------------------
def test_anki_connection():
    """Test if Anki is running and AnkiConnect is available"""
    try:
        logger.info("Testing Anki connection...")
        response = requests.post(
            "http://localhost:8765",
            json={"action": "version", "version": 6},
            timeout=5
        )
        result = response.json()
        if result.get("error"):
            logger.error(f"Anki connection error: {result['error']}")
            return False, result["error"]
        logger.info(f"Anki connected! Version: {result.get('result')}")
        return True, None
    except requests.exceptions.ConnectionError:
        error_msg = "Cannot connect to Anki. Make sure Anki is running and AnkiConnect addon is installed."
        logger.error(error_msg)
        return False, error_msg
    except requests.exceptions.Timeout:
        error_msg = "Anki connection timed out. Make sure Anki is not busy."
        logger.error(error_msg)
        return False, error_msg
    except Exception as e:
        error_msg = f"Unexpected error connecting to Anki: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return False, error_msg


def anki_request(action, **params):
    """Send request to Anki - with retry logic"""
    max_retries = 2
    for attempt in range(max_retries):
        try:
            logger.debug(f"Anki request: {action} (attempt {attempt + 1}/{max_retries})")
            res = requests.post("http://localhost:8765",
                                json={"action": action, "version": 6, "params": params},
                                timeout=15)
            obj = res.json()
            if obj.get("error"):
                logger.error(f"Anki error on {action}: {obj['error']}")
                print(f"Anki error: {obj['error']}")
                raise RuntimeError(obj["error"])
            logger.debug(f"Anki request {action} successful")
            return obj.get("result")
        except requests.exceptions.ConnectionError as e:
            error_msg = "Cannot connect to Anki. Make sure Anki is running."
            logger.error(f"Connection error (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(1)
                continue
            print(f"❌ {error_msg}")
            return None
        except requests.exceptions.Timeout as e:
            error_msg = "Anki request timed out"
            logger.error(f"Timeout error (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(1)
                continue
            print(f"❌ {error_msg}")
            return None
        except Exception as e:
            logger.error(f"Anki request failed (attempt {attempt + 1}): {e}", exc_info=True)
            if attempt < max_retries - 1:
                time.sleep(1)
                continue
            print(f"Anki request failed: {e}")
            return None
    return None


def ensure_deck_exists(deck_name):
    """Ensure the specified deck exists in Anki"""
    max_retries = 3
    for attempt in range(max_retries):
        try:
            logger.info(f"Ensuring deck exists: {deck_name} (attempt {attempt + 1}/{max_retries})")
            result = anki_request("createDeck", deck=deck_name)
            if result is not None:
                logger.info(f"Deck '{deck_name}' ready")
                return True
            time.sleep(0.5)
        except Exception as e:
            logger.error(f"Error ensuring deck exists (attempt {attempt + 1}): {e}", exc_info=True)
            if attempt < max_retries - 1:
                time.sleep(1)
            else:
                raise RuntimeError(f"Failed to create deck '{deck_name}' after {max_retries} attempts")
    return False


def add_audio_to_image_card(audio_path, image_path, deck_name, notes=""):
    """Add 1 card: Audio front → Image back (AnkiConnect)"""
    try:
        logger.info(f"Adding Audio->Image card to '{deck_name}'")
        ensure_deck_exists(deck_name)

        base_audio = os.path.basename(audio_path)
        base_img = os.path.basename(image_path)

        note = {
            "deckName": deck_name,
            "modelName": ANKI_MODEL_NAME,
            "fields": {"Front": notes, "Back": ""},
            "options": {"allowDuplicate": False},
            "audio": [{"path": audio_path, "filename": base_audio, "fields": ["Front"]}],
            "picture": [{"path": image_path, "filename": base_img, "fields": ["Back"]}],
        }

        result = anki_request("addNote", note=note)
        if not result:
            raise RuntimeError("Failed to add note to Anki")

        logger.info(f"SUCCESS: Audio->Image card added: {result}")
        return result
    except Exception as e:
        logger.error(f"Failed to add Audio->Image card: {e}", exc_info=True)
        return None


def add_image_to_audio_card(audio_path, image_path, deck_name, notes=""):
    """Add 1 card: Image front → Audio back (AnkiConnect)"""
    try:
        logger.info(f"Adding Image->Audio card to '{deck_name}'")
        ensure_deck_exists(deck_name)

        base_audio = os.path.basename(audio_path)
        base_img = os.path.basename(image_path)

        note = {
            "deckName": deck_name,
            "modelName": ANKI_MODEL_NAME,
            "fields": {"Front": notes, "Back": ""},
            "options": {"allowDuplicate": False},
            "audio": [{"path": audio_path, "filename": base_audio, "fields": ["Back"]}],
            "picture": [{"path": image_path, "filename": base_img, "fields": ["Front"]}],
        }

        result = anki_request("addNote", note=note)
        if not result:
            raise RuntimeError("Failed to add note to Anki")

        logger.info(f"SUCCESS: Image->Audio card added: {result}")
        return result
    except Exception as e:
        logger.error(f"Failed to add Image->Audio card: {e}", exc_info=True)
        return None


def add_both_direction_cards(audio_path, image_path, deck_name, notes=""):
    """Add 2 cards: Audio→Image + Image→Audio (AnkiConnect)"""
    try:
        logger.info(f"Adding both direction cards to '{deck_name}'")
        ensure_deck_exists(deck_name)

        base_audio = os.path.basename(audio_path)
        base_img = os.path.basename(image_path)

        # Card 1: Audio → Image
        note1 = {
            "deckName": deck_name,
            "modelName": ANKI_MODEL_NAME,
            "fields": {"Front": notes, "Back": ""},
            "options": {"allowDuplicate": False},
            "audio": [{"path": audio_path, "filename": base_audio, "fields": ["Front"]}],
            "picture": [{"path": image_path, "filename": base_img, "fields": ["Back"]}],
        }

        # Card 2: Image → Audio
        note2 = {
            "deckName": deck_name,
            "modelName": ANKI_MODEL_NAME,
            "fields": {"Front": notes, "Back": ""},
            "options": {"allowDuplicate": False},
            "audio": [{"path": audio_path, "filename": base_audio, "fields": ["Back"]}],
            "picture": [{"path": image_path, "filename": base_img, "fields": ["Front"]}],
        }

        result = anki_request("addNotes", notes=[note1, note2])
        if not result:
            raise RuntimeError("Failed to add notes to Anki")

        logger.info(f"SUCCESS: Both direction cards added: {result}")
        return result
    except Exception as e:
        logger.error(f"Failed to add both direction cards: {e}", exc_info=True)
        return None


def add_audio_to_gif_card(audio_path, gif_path, deck_name, notes=""):
    """Add 1 card: Audio front → GIF back (AnkiConnect)"""
    try:
        logger.info(f"Adding Audio->GIF card to '{deck_name}'")
        ensure_deck_exists(deck_name)

        base_audio = os.path.basename(audio_path)
        # Handle gif_path as either string or list
        if isinstance(gif_path, list):
            gif_path = gif_path[0] if gif_path else None
        if not gif_path:
            raise ValueError("No GIF path provided")
        base_gif = os.path.basename(gif_path)

        note = {
            "deckName": deck_name,
            "modelName": ANKI_MODEL_NAME,
            "fields": {"Front": notes, "Back": ""},
            "options": {"allowDuplicate": False},
            "audio": [{"path": audio_path, "filename": base_audio, "fields": ["Front"]}],
            "picture": [{"path": gif_path, "filename": base_gif, "fields": ["Back"]}],
        }

        result = anki_request("addNote", note=note)
        if not result:
            raise RuntimeError("Failed to add note to Anki")

        logger.info(f"SUCCESS: Audio->GIF card added: {result}")
        return result
    except Exception as e:
        logger.error(f"Failed to add Audio->GIF card: {e}", exc_info=True)
        return None


def add_audio_to_screenshots_card(audio_path, screenshot_paths, deck_name, notes=""):
    """Add 1 card: Audio front → Multiple Screenshots back (AnkiConnect)"""
    try:
        logger.info(f"Adding Audio->Screenshots card to '{deck_name}' with {len(screenshot_paths)} images")
        ensure_deck_exists(deck_name)

        base_audio = os.path.basename(audio_path)
        
        # Prepare picture list for all screenshots
        pictures = []
        for img_path in screenshot_paths:
            base_img = os.path.basename(img_path)
            pictures.append({"path": img_path, "filename": base_img, "fields": ["Back"]})

        note = {
            "deckName": deck_name,
            "modelName": ANKI_MODEL_NAME,
            "fields": {"Front": notes, "Back": ""},
            "options": {"allowDuplicate": False},
            "audio": [{"path": audio_path, "filename": base_audio, "fields": ["Front"]}],
            "picture": pictures,
        }

        result = anki_request("addNote", note=note)
        if not result:
            raise RuntimeError("Failed to add note to Anki")

        logger.info(f"SUCCESS: Audio->Screenshots card added: {result}")
        return result
    except Exception as e:
        logger.error(f"Failed to add Audio->Screenshots card: {e}", exc_info=True)
        return None


# --------------------------------
# FlashLearn helpers
# --------------------------------
FLASHLEARN_BASE_URL = "http://localhost:3000"
FLASHLEARN_TOKEN_FILE = os.path.join(SAVE_DIR, ".flashlearn_token")

# Cache for FlashLearn token and group
_flashlearn_token = None
_flashlearn_group_id = None
_flashlearn_group_name = None

# Pending FlashLearn action (to resume after login)
_flashlearn_pending_action = None


def flashlearn_save_token(token):
    """Save token to file for persistence"""
    try:
        with open(FLASHLEARN_TOKEN_FILE, 'w') as f:
            f.write(token)
        logger.info("FlashLearn token saved to file")
    except Exception as e:
        logger.error(f"Failed to save FlashLearn token: {e}")


def flashlearn_load_token():
    """Load token from file"""
    global _flashlearn_token
    try:
        if os.path.exists(FLASHLEARN_TOKEN_FILE):
            with open(FLASHLEARN_TOKEN_FILE, 'r') as f:
                token = f.read().strip()
                if token:
                    _flashlearn_token = token
                    logger.info("FlashLearn token loaded from file")
                    return token
    except Exception as e:
        logger.error(f"Failed to load FlashLearn token: {e}")
    return None


def flashlearn_clear_token():
    """Clear saved token"""
    global _flashlearn_token
    _flashlearn_token = None
    try:
        if os.path.exists(FLASHLEARN_TOKEN_FILE):
            os.remove(FLASHLEARN_TOKEN_FILE)
            logger.info("FlashLearn token cleared")
    except Exception as e:
        logger.error(f"Failed to clear FlashLearn token: {e}")


def flashlearn_is_authenticated():
    """Check if we have a valid token"""
    token = flashlearn_get_token()
    if not token:
        return False
    
    # Verify token is still valid by making a test request
    try:
        response = requests.get(
            f"{FLASHLEARN_BASE_URL}/group",
            headers={"Authorization": f"Bearer {token}"},
            timeout=5
        )
        return response.status_code == 200
    except:
        return False


def flashlearn_device_auth_start():
    """Start device authorization flow - returns user_code and verification URL"""
    try:
        logger.info("Starting FlashLearn device authorization...")
        response = requests.post(
            f"{FLASHLEARN_BASE_URL}/device-auth/request",
            json={"device_name": "Anki Capture Studio"},
            timeout=10
        )
        if response.status_code == 200 or response.status_code == 201:
            data = response.json()
            return {
                'user_code': data.get('user_code'),
                'device_code': data.get('device_code'),
                'verification_uri': data.get('verification_uri', f"{FLASHLEARN_BASE_URL}/authorize/{data.get('user_code')}"),
                'expires_in': data.get('expires_in', 300),
                'interval': data.get('interval', 5)
            }
        else:
            logger.error(f"Device auth start failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logger.error(f"Device auth start error: {e}", exc_info=True)
        return None


def flashlearn_device_auth_poll(device_code):
    """Poll for device authorization completion"""
    try:
        response = requests.post(
            f"{FLASHLEARN_BASE_URL}/device-auth/poll",
            json={"device_code": device_code},
            timeout=10
        )
        # Accept both 200 and 201 status codes
        if response.status_code in (200, 201):
            data = response.json()
            logger.debug(f"Poll response: {data}")
            # Server returns access_token when authorized, or error when pending
            token = data.get('access_token')
            error = data.get('error')
            
            if token:
                global _flashlearn_token
                _flashlearn_token = token
                flashlearn_save_token(token)
                logger.info("Device authorization successful!")
                return {'status': 'success', 'token': token}
            elif error == 'authorization_pending':
                return {'status': 'pending'}
            elif error == 'expired_token':
                return {'status': 'expired'}
            elif error == 'access_denied':
                return {'status': 'denied'}
            else:
                return {'status': 'pending'}
        return {'status': 'error'}
    except Exception as e:
        logger.error(f"Device auth poll error: {e}")
        return {'status': 'error'}


def flashlearn_set_pending_action(action_func, *args, **kwargs):
    """Store a pending action to execute after login"""
    global _flashlearn_pending_action
    _flashlearn_pending_action = {
        'func': action_func,
        'args': args,
        'kwargs': kwargs
    }
    logger.info("Pending FlashLearn action stored")


def flashlearn_execute_pending_action():
    """Execute the pending action after successful login"""
    global _flashlearn_pending_action
    if _flashlearn_pending_action:
        action = _flashlearn_pending_action
        _flashlearn_pending_action = None
        logger.info("Executing pending FlashLearn action...")
        try:
            return action['func'](*action['args'], **action['kwargs'])
        except Exception as e:
            logger.error(f"Failed to execute pending action: {e}", exc_info=True)
            return None
    return None


def flashlearn_clear_pending_action():
    """Clear any pending action"""
    global _flashlearn_pending_action
    _flashlearn_pending_action = None


def flashlearn_get_token():
    """Get cached token, load from file, or return None"""
    global _flashlearn_token
    if _flashlearn_token:
        return _flashlearn_token
    # Try to load from file
    return flashlearn_load_token()


def flashlearn_get_groups():
    """Get all groups from FlashLearn"""
    token = flashlearn_get_token()
    if not token:
        return None
    
    try:
        logger.info("Fetching FlashLearn groups...")
        response = requests.get(
            f"{FLASHLEARN_BASE_URL}/group",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("data", []) if isinstance(data, dict) else []
        else:
            logger.error(f"FlashLearn get groups failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logger.error(f"FlashLearn get groups error: {e}", exc_info=True)
        return None


def flashlearn_find_group_by_name(group_name):
    """Find a group by name in FlashLearn (searches recursively through nested groups)"""
    groups = flashlearn_get_groups()
    if not groups:
        return None
    
    def search_groups(groups_list, target_name):
        for group in groups_list:
            if group.get("name") == target_name:
                return group.get("id")
            children = group.get("children", [])
            if children:
                result = search_groups(children, target_name)
                if result:
                    return result
        return None
    
    return search_groups(groups, group_name)


def flashlearn_create_group(group_name):
    """Create a group in FlashLearn or return existing one"""
    global _flashlearn_group_id, _flashlearn_group_name
    
    token = flashlearn_get_token()
    if not token:
        return None
    
    # Always check if the group exists on the server (don't trust cache)
    # This ensures we don't use a deleted group ID
    existing_group_id = flashlearn_find_group_by_name(group_name)
    if existing_group_id:
        logger.info(f"Found existing FlashLearn group: {existing_group_id}")
        _flashlearn_group_id = existing_group_id
        _flashlearn_group_name = group_name
        return existing_group_id
    
    # If not found, create a new group
    try:
        logger.info(f"Creating FlashLearn group: {group_name}")
        response = requests.post(
            f"{FLASHLEARN_BASE_URL}/group",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            json={"name": group_name},
            timeout=10
        )
        if response.status_code == 200 or response.status_code == 201:
            data = response.json()
            _flashlearn_group_id = data.get("data", {}).get("id")
            _flashlearn_group_name = group_name
            logger.info(f"FlashLearn group created: {_flashlearn_group_id}")
            return _flashlearn_group_id
        else:
            logger.error(f"FlashLearn create group failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logger.error(f"FlashLearn create group error: {e}", exc_info=True)
        return None


def flashlearn_upload_file(file_path):
    """Upload a file to FlashLearn server and return the URL"""
    token = flashlearn_get_token()
    if not token:
        return None
    
    if not os.path.exists(file_path):
        logger.error(f"File not found: {file_path}")
        return None
    
    try:
        logger.info(f"Uploading file to FlashLearn: {file_path}")
        with open(file_path, 'rb') as f:
            files = {'file': (os.path.basename(file_path), f)}
            response = requests.post(
                f"{FLASHLEARN_BASE_URL}/upload/file",
                headers={"Authorization": f"Bearer {token}"},
                files=files,
                timeout=30
            )
        
        if response.status_code == 200 or response.status_code == 201:
            data = response.json()
            file_url = data.get("url")
            if file_url:
                # Keep relative URL (e.g., /uploads/file.ext) for frontend compatibility
                logger.info(f"File uploaded successfully: {file_url}")
                return file_url
            else:
                logger.error(f"No URL in upload response: {data}")
                return None
        else:
            logger.error(f"File upload failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logger.error(f"File upload error: {e}", exc_info=True)
        return None


def flashlearn_add_card(group_id, question_text, question_type, answer_text, answer_type,
                        question_media_url=None, answer_media_url=None):
    """Add a card to a FlashLearn group"""
    token = flashlearn_get_token()
    if not token:
        return None
    
    try:
        logger.info(f"Adding card to FlashLearn group: {group_id}")
        body = {
            "questionType": question_type,
            "answerType": answer_type
        }
        # Only add text fields if they're not empty
        if question_text and question_text.strip():
            body["questionText"] = question_text
        if answer_text and answer_text.strip():
            body["answerText"] = answer_text
        if question_media_url:
            body["questionMediaUrl"] = question_media_url
        if answer_media_url:
            body["answerMediaUrl"] = answer_media_url
        
        response = requests.post(
            f"{FLASHLEARN_BASE_URL}/group/{group_id}/card",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            json=body,
            timeout=10
        )
        if response.status_code == 200 or response.status_code == 201:
            data = response.json()
            # Try different response formats
            card_id = data.get("data", {}).get("id") or data.get("id") or True
            logger.info(f"FlashLearn card added: {card_id}")
            return card_id
        else:
            logger.error(f"FlashLearn add card failed: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logger.error(f"FlashLearn add card error: {e}", exc_info=True)
        return None


def test_flashlearn_connection():
    """Test if FlashLearn server is running"""
    try:
        logger.info("Testing FlashLearn connection...")
        response = requests.get(f"{FLASHLEARN_BASE_URL}/", timeout=5)
        if response.status_code < 500:
            logger.info("FlashLearn server is reachable")
            return True, None
        return False, f"Server returned status {response.status_code}"
    except requests.exceptions.ConnectionError:
        error_msg = "Cannot connect to FlashLearn. Make sure the server is running on localhost:3000"
        logger.error(error_msg)
        return False, error_msg
    except Exception as e:
        error_msg = f"FlashLearn connection error: {str(e)}"
        logger.error(error_msg)
        return False, error_msg


def add_audio_to_image_card_flashlearn(audio_path, image_path, deck_name, notes=""):
    """Add Audio->Image card to FlashLearn"""
    try:
        logger.info(f"Adding Audio->Image card to FlashLearn group '{deck_name}'")
        
        group_id = flashlearn_create_group(deck_name)
        if not group_id:
            raise RuntimeError("Failed to create/get FlashLearn group")
        
        # Upload files to server
        logger.info("Uploading audio file...")
        audio_url = flashlearn_upload_file(audio_path)
        if not audio_url:
            raise RuntimeError("Failed to upload audio file")
        
        logger.info("Uploading image file...")
        image_url = flashlearn_upload_file(image_path)
        if not image_url:
            raise RuntimeError("Failed to upload image file")
        
        result = flashlearn_add_card(
            group_id=group_id,
            question_text=notes if notes else "",
            question_type="AUDIO",
            question_media_url=audio_url,
            answer_text="",
            answer_type="IMAGE",
            answer_media_url=image_url
        )
        
        if result:
            logger.info(f"SUCCESS: Audio->Image card added to FlashLearn: {result}")
            return result
        else:
            raise RuntimeError("Failed to add card to FlashLearn")
    except Exception as e:
        logger.error(f"Failed to add Audio->Image card to FlashLearn: {e}", exc_info=True)
        return None


def add_image_to_audio_card_flashlearn(audio_path, image_path, deck_name, notes=""):
    """Add Image->Audio card to FlashLearn"""
    try:
        logger.info(f"Adding Image->Audio card to FlashLearn group '{deck_name}'")
        
        group_id = flashlearn_create_group(deck_name)
        if not group_id:
            raise RuntimeError("Failed to create/get FlashLearn group")
        
        # Upload files to server
        logger.info("Uploading audio file...")
        audio_url = flashlearn_upload_file(audio_path)
        if not audio_url:
            raise RuntimeError("Failed to upload audio file")
        
        logger.info("Uploading image file...")
        image_url = flashlearn_upload_file(image_path)
        if not image_url:
            raise RuntimeError("Failed to upload image file")
        
        result = flashlearn_add_card(
            group_id=group_id,
            question_text=notes if notes else "",
            question_type="IMAGE",
            question_media_url=image_url,
            answer_text="",
            answer_type="AUDIO",
            answer_media_url=audio_url
        )
        
        if result:
            logger.info(f"SUCCESS: Image->Audio card added to FlashLearn: {result}")
            return result
        else:
            raise RuntimeError("Failed to add card to FlashLearn")
    except Exception as e:
        logger.error(f"Failed to add Image->Audio card to FlashLearn: {e}", exc_info=True)
        return None


def add_both_direction_cards_flashlearn(audio_path, image_path, deck_name, notes=""):
    """Add both direction cards to FlashLearn"""
    try:
        logger.info(f"Adding both direction cards to FlashLearn group '{deck_name}'")
        
        group_id = flashlearn_create_group(deck_name)
        if not group_id:
            raise RuntimeError("Failed to create/get FlashLearn group")
        
        # Upload files to server
        logger.info("Uploading audio file...")
        audio_url = flashlearn_upload_file(audio_path)
        if not audio_url:
            raise RuntimeError("Failed to upload audio file")
        
        logger.info("Uploading image file...")
        image_url = flashlearn_upload_file(image_path)
        if not image_url:
            raise RuntimeError("Failed to upload image file")
        
        # Card 1: Audio -> Image
        result1 = flashlearn_add_card(
            group_id=group_id,
            question_text=notes if notes else "",
            question_type="AUDIO",
            question_media_url=audio_url,
            answer_text="",
            answer_type="IMAGE",
            answer_media_url=image_url
        )
        
        # Card 2: Image -> Audio
        result2 = flashlearn_add_card(
            group_id=group_id,
            question_text=notes if notes else "",
            question_type="IMAGE",
            question_media_url=image_url,
            answer_text="",
            answer_type="AUDIO",
            answer_media_url=audio_url
        )
        
        if result1 and result2:
            logger.info(f"SUCCESS: Both direction cards added to FlashLearn")
            return [result1, result2]
        else:
            raise RuntimeError("Failed to add cards to FlashLearn")
    except Exception as e:
        logger.error(f"Failed to add both direction cards to FlashLearn: {e}", exc_info=True)
        return None


def add_audio_to_gif_card_flashlearn(audio_path, gif_path, deck_name, notes=""):
    """Add Audio->GIF card to FlashLearn"""
    try:
        logger.info(f"Adding Audio->GIF card to FlashLearn group '{deck_name}'")
        
        group_id = flashlearn_create_group(deck_name)
        if not group_id:
            raise RuntimeError("Failed to create/get FlashLearn group")
        
        if isinstance(gif_path, list):
            gif_path = gif_path[0] if gif_path else None
        if not gif_path:
            raise ValueError("No GIF path provided")
        
        # Upload files to server
        logger.info("Uploading audio file...")
        audio_url = flashlearn_upload_file(audio_path)
        if not audio_url:
            raise RuntimeError("Failed to upload audio file")
        
        logger.info("Uploading GIF file...")
        gif_url = flashlearn_upload_file(gif_path)
        if not gif_url:
            raise RuntimeError("Failed to upload GIF file")
        
        result = flashlearn_add_card(
            group_id=group_id,
            question_text=notes if notes else "",
            question_type="AUDIO",
            question_media_url=audio_url,
            answer_text="",
            answer_type="IMAGE",  # GIF is treated as image
            answer_media_url=gif_url
        )
        
        if result:
            logger.info(f"SUCCESS: Audio->GIF card added to FlashLearn: {result}")
            return result
        else:
            raise RuntimeError("Failed to add card to FlashLearn")
    except Exception as e:
        logger.error(f"Failed to add Audio->GIF card to FlashLearn: {e}", exc_info=True)
        return None


def add_audio_to_screenshots_card_flashlearn(audio_path, screenshot_paths, deck_name, notes=""):
    """Add Audio->Screenshots card to FlashLearn (creates 1 card with all screenshots combined)"""
    try:
        logger.info(f"Adding Audio->Screenshots card to FlashLearn group '{deck_name}'")
        
        group_id = flashlearn_create_group(deck_name)
        if not group_id:
            raise RuntimeError("Failed to create/get FlashLearn group")
        
        # Normalize screenshot_paths to a list
        if isinstance(screenshot_paths, str):
            screenshot_paths = [screenshot_paths]
        elif not isinstance(screenshot_paths, list) or len(screenshot_paths) == 0:
            raise ValueError("No screenshot paths provided")
        
        # Upload audio file
        logger.info("Uploading audio file...")
        audio_url = flashlearn_upload_file(audio_path)
        if not audio_url:
            raise RuntimeError("Failed to upload audio file")
        
        # Upload all screenshots and collect URLs
        image_urls = []
        for i, img_path in enumerate(screenshot_paths):
            logger.info(f"Uploading screenshot {i+1}/{len(screenshot_paths)}...")
            image_url = flashlearn_upload_file(img_path)
            if image_url:
                image_urls.append(image_url)
            else:
                logger.error(f"Failed to upload screenshot {i+1}: {img_path}")
        
        if not image_urls:
            raise RuntimeError("Failed to upload any screenshots")
        
        # Combine all image URLs with comma separator for multiple images
        # Frontend will split and display all images
        combined_image_urls = ",".join(image_urls)
        logger.info(f"Combined {len(image_urls)} screenshot URLs")
        
        result = flashlearn_add_card(
            group_id=group_id,
            question_text=notes if notes else "",
            question_type="AUDIO",
            question_media_url=audio_url,
            answer_text="",
            answer_type="IMAGE",
            answer_media_url=combined_image_urls
        )
        
        if result:
            logger.info(f"SUCCESS: Audio->Screenshots card added to FlashLearn with {len(image_urls)} images")
            return result
        else:
            raise RuntimeError("Failed to add card to FlashLearn")
    except Exception as e:
        logger.error(f"Failed to add Audio->Screenshots card to FlashLearn: {e}", exc_info=True)
        return None


# --------------------------------
# genanki helpers for .apkg export
# --------------------------------
def export_genanki_package(notes, media_files, deck_name, apkg_filename):
    """
    notes: list of (front_html, back_html)
    media_files: list of full paths
    """
    try:
        logger.info(f"Exporting .apkg: {apkg_filename}")

        model = genanki.Model(
            GENANKI_MODEL_ID,
            ANKI_MODEL_NAME,
            fields=[
                {"name": "Front"},
                {"name": "Back"},
            ],
            templates=[
                {
                    "name": "Card 1",
                    "qfmt": "{{Front}}",
                    "afmt": "{{Front}}<hr id=\"answer\">{{Back}}",
                }
            ]
        )

        deck = genanki.Deck(GENANKI_DECK_ID, deck_name)

        for front, back in notes:
            note = genanki.Note(
                model=model,
                fields=[front, back]
            )
            deck.add_note(note)

        pkg = genanki.Package(deck)
        pkg.media_files = media_files

        out_path = os.path.join(SAVE_DIR, apkg_filename)
        pkg.write_to_file(out_path)

        logger.info(f".apkg written to {out_path}")
        return out_path
    except Exception as e:
        logger.error(f"Failed to export .apkg: {e}", exc_info=True)
        return None


def export_audio_to_image_apkg(audio_path, image_path, deck_name, apkg_name, notes=""):
    base_audio = os.path.basename(audio_path)
    base_img = os.path.basename(image_path)
    front = f"{notes}<br>[sound:{base_audio}]" if notes else f"[sound:{base_audio}]"
    back = f"<img src='{base_img}'>"
    return export_genanki_package(
        [(front, back)],
        [audio_path, image_path],
        deck_name,
        apkg_name
    )


def export_image_to_audio_apkg(audio_path, image_path, deck_name, apkg_name):
    base_audio = os.path.basename(audio_path)
    base_img = os.path.basename(image_path)
    front = f"<img src='{base_img}'>"
    back = f"[sound:{base_audio}]"
    return export_genanki_package(
        [(front, back)],
        [audio_path, image_path],
        deck_name,
        apkg_name
    )


def export_both_directions_apkg(audio_path, image_path, deck_name, apkg_name):
    base_audio = os.path.basename(audio_path)
    base_img = os.path.basename(image_path)

    notes = [
        (f"[sound:{base_audio}]", f"<img src='{base_img}'>"),
        (f"<img src='{base_img}'>", f"[sound:{base_audio}]"),
    ]
    return export_genanki_package(
        notes,
        [audio_path, image_path],
        deck_name,
        apkg_name
    )


def export_audio_to_gif_apkg(audio_path, gif_path, deck_name, apkg_name):
    base_audio = os.path.basename(audio_path)
    # Handle gif_path as either string or list
    if isinstance(gif_path, list):
        gif_path = gif_path[0] if gif_path else None
    if not gif_path:
        raise ValueError("No GIF path provided")
    base_gif = os.path.basename(gif_path)
    front = f"[sound:{base_audio}]"
    back = f"<img src='{base_gif}'>"
    return export_genanki_package(
        [(front, back)],
        [audio_path, gif_path],
        deck_name,
        apkg_name
    )


def export_audio_to_screenshots_apkg(audio_path, screenshot_paths, deck_name, apkg_name):
    base_audio = os.path.basename(audio_path)
    front = f"[sound:{base_audio}]"
    
    # Create HTML with all screenshots stacked vertically
    back_html = ""
    for img_path in screenshot_paths:
        base_img = os.path.basename(img_path)
        back_html += f"<img src='{base_img}'><br>"
    
    media_files = [audio_path] + screenshot_paths
    return export_genanki_package(
        [(front, back_html)],
        media_files,
        deck_name,
        apkg_name
    )


# --------------------------------
# App GUI
# --------------------------------
class App:
    def __init__(self, root):
        try:
            logger.info("Initializing App...")
            self.root = root
            root.title("Anki Capture Studio")
            root.geometry("900x750")  # Reduced height for better fit
            root.resizable(True, True)
            root.minsize(700, 600)

            self.colors = {
                'bg': '#1e1e2e', 'fg': '#cdd6f4', 'accent': '#89b4fa',
                'success': '#a6e3a1', 'error': '#f38ba8', 'card': '#313244',
                'hover': '#45475a', 'border': '#585b70',
                'mode1': '#f9e2af', 'mode2': '#cba6f7', 'mode3': '#94e2d5',
                'mode5': '#fab387', 'mode6': '#f5c2e7'
            }
            root.configure(bg=self.colors['bg'])

            self.load_settings()
            
            # Only test Anki connection if export mode is set to Anki
            self.anki_connected = False
            anki_error = None
            if self.export_mode.get() == "Send to Anki":
                self.anki_connected, anki_error = test_anki_connection()
                if not self.anki_connected:
                    logger.warning(f"Anki not connected: {anki_error}")

            try:
                self.devices = [s.name for s in sc.all_speakers()]
                logger.info(f"Found {len(self.devices)} audio devices")
            except Exception as e:
                logger.error(f"Error getting audio devices: {e}", exc_info=True)
                self.devices = []

            if not hasattr(self, 'selected_device') or self.selected_device.get() not in self.devices:
                try:
                    default_dev = sc.default_speaker().name if sc.default_speaker() else (self.devices[0] if self.devices else "")
                    self.selected_device = tk.StringVar(value=default_dev)
                except Exception as e:
                    logger.error(f"Error setting default device: {e}", exc_info=True)
                    self.selected_device = tk.StringVar(value="")

            # Buffer needs to be bigger to support max delays
            max_buffer_size = max(60, self.seconds.get() * 3)
            self.rbuf = RollingBuffer(max_buffer_size, SAMPLE_RATE, CHANNELS)
            self.rec = LoopbackRecorder(self.selected_device.get(), self.rbuf)
            self.rec.start()

            self.screenshotter = RollingScreenshot(
                interval=self.screenshot_interval.get(),
                monitor_index=self.monitor_index.get(),
                max_history_seconds=max(60, self.seconds.get() * 4)
            )
            self.screenshotter.start()

            self.tray_icon = None
            self.is_minimized = False
            self.capturing_hotkey = False
            self.capture_buttons = []  # Store references to update labels
            
            # Editor Mode capture list
            self.editor_mode_captures = []  # List of capture dicts: {audio_path, image_paths, gif_path, mode_name, send_func, export_func}
            self.current_capture_index = 0  # Currently viewed capture index

            self.monitor_label_var = tk.StringVar()

            self._setup_styles()
            self._build_ui()
            
            # Show editor panel if it was enabled in settings
            if self.show_editor_panel_default:
                self.root.after(100, self._toggle_editor_panel)
            
            # Activate Multi-Capture Mode if it was enabled in settings
            if self.editor_mode_default:
                self.root.after(150, self._on_editor_mode_toggle)

            root.protocol("WM_DELETE_WINDOW", self.on_closing)

            import keyboard
            self.keyboard = keyboard
            threading.Thread(target=self._hotkey_loop, daemon=True).start()
            self._update_status()
            logger.info("App initialization complete")

            if not self.anki_connected and self.export_mode.get() == "Send to Anki" and anki_error:
                self.show_error("⚠️ Anki Warning",
                                f"Cannot connect to Anki:\n{anki_error}\n\n"
                                "Make sure Anki is running and AnkiConnect addon is installed.\n"
                                "You can still capture to disk or export .apkg.")

        except Exception as e:
            logger.critical(f"Failed to initialize app: {e}", exc_info=True)
            messagebox.showerror("Startup Error",
                                 f"Failed to start application:\n{str(e)}")
            raise

    def load_settings(self):
        logger.info("Loading settings...")
        defaults = {
            'seconds': DEFAULT_SECONDS,
            'hotkey_audio_to_image': DEFAULT_HOTKEY_AUDIO_TO_IMAGE,
            'hotkey_image_to_audio': DEFAULT_HOTKEY_IMAGE_TO_AUDIO,
            'hotkey_both_directions': DEFAULT_HOTKEY_BOTH_DIRECTIONS,
            'hotkey_audio_to_video': DEFAULT_HOTKEY_AUDIO_TO_VIDEO,
            'hotkey_audio_to_screenshots': DEFAULT_HOTKEY_AUDIO_TO_SCREENSHOTS,
            'deck_name': DEFAULT_DECK_NAME,
            'monitor': 1,
            'export_mode': 'Send to Anki',
            'device': '',
            'audio_before_seconds': 1.0,
            'screenshot_offset_seconds': 0.0,
            'gif_speed_ms': DEFAULT_GIF_SPEED,
            'apkg_audio': DEFAULT_APKG_AUDIO_NAME,
            'apkg_image': DEFAULT_APKG_IMAGE_NAME,
            'apkg_gif': DEFAULT_APKG_GIF_NAME,
            'apkg_screenshots': DEFAULT_APKG_SCREENSHOTS_NAME,
            'use_region': 'False',
            'region_x': '0',
            'region_y': '0',
            'region_width': '0',
            'region_height': '0',
            'use_editor': 'True',
            'editor_layout': 'bottom',
            'show_editor_panel': 'False',
            'screenshot_interval': '0.5',
            'editor_mode': 'False'
        }

        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, 'r') as f:
                    for line in f:
                        if '=' in line:
                            key, val = line.strip().split('=', 1)
                            defaults[key] = val
            except:
                pass

        self.seconds = tk.IntVar(value=int(float(defaults['seconds'])))
        self.hotkey_audio_to_image = tk.StringVar(value=str(defaults['hotkey_audio_to_image']))
        self.hotkey_image_to_audio = tk.StringVar(value=str(defaults['hotkey_image_to_audio']))
        self.hotkey_both_directions = tk.StringVar(value=str(defaults['hotkey_both_directions']))
        self.hotkey_audio_to_video = tk.StringVar(value=str(defaults['hotkey_audio_to_video']))
        self.hotkey_audio_to_screenshots = tk.StringVar(value=str(defaults['hotkey_audio_to_screenshots']))
        self.deck_name = tk.StringVar(value=str(defaults['deck_name']))
        self.monitor_index = tk.IntVar(value=int(float(defaults['monitor'])))
        self.export_mode = tk.StringVar(value=str(defaults['export_mode']))
        self.selected_device = tk.StringVar(value=str(defaults['device']))
        self.audio_before_seconds = tk.DoubleVar(value=float(defaults['audio_before_seconds']))
        self.screenshot_offset_seconds = tk.DoubleVar(value=float(defaults['screenshot_offset_seconds']))
        self.gif_speed_ms = tk.IntVar(value=int(float(defaults['gif_speed_ms'])))
        self.apkg_audio_name = tk.StringVar(value=str(defaults['apkg_audio']))
        self.apkg_image_name = tk.StringVar(value=str(defaults['apkg_image']))
        self.apkg_gif_name = tk.StringVar(value=str(defaults['apkg_gif']))
        self.apkg_screenshots_name = tk.StringVar(value=str(defaults['apkg_screenshots']))
        self.use_region = tk.BooleanVar(value=defaults['use_region'] == 'True')
        self.region_x = tk.IntVar(value=int(float(defaults['region_x'])))
        self.region_y = tk.IntVar(value=int(float(defaults['region_y'])))
        self.region_width = tk.IntVar(value=int(float(defaults['region_width'])))
        self.region_height = tk.IntVar(value=int(float(defaults['region_height'])))
        self.use_editor = tk.BooleanVar(value=defaults['use_editor'] == 'True')
        # Load editor layout preference (will be set later in _build_ui)
        self.editor_layout_default = defaults.get('editor_layout', 'bottom')
        self.show_editor_panel_default = defaults.get('show_editor_panel', 'False') == 'True'
        self.screenshot_interval = tk.DoubleVar(value=float(defaults.get('screenshot_interval', '0.5')))
        self.editor_mode_default = defaults.get('editor_mode', 'False') == 'True'
        logger.info("Settings loaded successfully")

    def save_settings(self):
        try:
            with open(SETTINGS_FILE, 'w') as f:
                f.write(f"seconds={self.seconds.get()}\n")
                f.write(f"hotkey_audio_to_image={self.hotkey_audio_to_image.get()}\n")
                f.write(f"hotkey_image_to_audio={self.hotkey_image_to_audio.get()}\n")
                f.write(f"hotkey_both_directions={self.hotkey_both_directions.get()}\n")
                f.write(f"hotkey_audio_to_video={self.hotkey_audio_to_video.get()}\n")
                f.write(f"hotkey_audio_to_screenshots={self.hotkey_audio_to_screenshots.get()}\n")
                f.write(f"deck_name={self.deck_name.get()}\n")
                f.write(f"monitor={self.monitor_index.get()}\n")
                f.write(f"export_mode={self.export_mode.get()}\n")
                f.write(f"device={self.selected_device.get()}\n")
                f.write(f"audio_before_seconds={self.audio_before_seconds.get()}\n")
                f.write(f"screenshot_offset_seconds={self.screenshot_offset_seconds.get()}\n")
                f.write(f"gif_speed_ms={self.gif_speed_ms.get()}\n")
                f.write(f"apkg_audio={self.apkg_audio_name.get()}\n")
                f.write(f"apkg_image={self.apkg_image_name.get()}\n")
                f.write(f"apkg_gif={self.apkg_gif_name.get()}\n")
                f.write(f"apkg_screenshots={self.apkg_screenshots_name.get()}\n")
                f.write(f"use_region={self.use_region.get()}\n")
                f.write(f"region_x={self.region_x.get()}\n")
                f.write(f"region_y={self.region_y.get()}\n")
                f.write(f"region_width={self.region_width.get()}\n")
                f.write(f"region_height={self.region_height.get()}\n")
                f.write(f"use_editor={self.use_editor.get()}\n")
                f.write(f"editor_layout={self.editor_layout.get()}\n")
                f.write(f"show_editor_panel={self.show_editor_panel.get()}\n")
                f.write(f"screenshot_interval={self.screenshot_interval.get()}\n")
                f.write(f"editor_mode={self.editor_mode.get()}\n")
        except Exception as e:
            logger.error(f"Error saving settings: {e}")

    def show_error(self, title, message):
        try:
            messagebox.showwarning(title, message)
        except Exception as e:
            logger.error(f"Failed to show error dialog: {e}")


    def test_anki(self):
        try:
            self.status.config(text="Testing Anki connection...", fg=self.colors['accent'])
            self.root.update()

            connected, error = test_anki_connection()
            if connected:
                messagebox.showinfo("Anki Connection", "✅ Successfully connected to Anki!\n\nAnkiConnect is working properly.")
                self.status.config(text="✅ Anki connection successful!", fg=self.colors['success'])
                self.anki_connected = True
            else:
                messagebox.showwarning("Anki Connection Failed",
                                       f"❌ Cannot connect to Anki:\n\n{error}\n\n"
                                       "Make sure:\n"
                                       "1. Anki is running\n"
                                       "2. AnkiConnect addon is installed\n"
                                       "3. Anki is not showing any dialog boxes")
                self.status.config(text=f"❌ Anki connection failed: {error}", fg=self.colors['error'])
                self.anki_connected = False
        except Exception as e:
            logger.error(f"Error testing Anki connection: {e}", exc_info=True)
            messagebox.showerror("Error", f"Error testing connection:\n{str(e)}")

    def test_flashlearn(self):
        try:
            self.status.config(text="Testing FlashLearn connection...", fg=self.colors['accent'])
            self.root.update()

            connected, error = test_flashlearn_connection()
            if connected:
                # Check if already authenticated
                if flashlearn_is_authenticated():
                    messagebox.showinfo("FlashLearn Connection", 
                                       "✅ Successfully connected to FlashLearn!\n\n"
                                       "Server is running and you are logged in.")
                    self.status.config(text="✅ FlashLearn connected and authenticated!", fg=self.colors['success'])
                else:
                    # Offer to login
                    result = messagebox.askyesno("FlashLearn Connection",
                                                "✅ FlashLearn server is running!\n\n"
                                                "You are not logged in yet.\n"
                                                "Would you like to login now?")
                    if result:
                        self._flashlearn_login_dialog()
                    else:
                        self.status.config(text="⚠️ FlashLearn server reachable but not logged in", fg=self.colors['error'])
            else:
                messagebox.showwarning("FlashLearn Connection Failed",
                                       f"❌ Cannot connect to FlashLearn:\n\n{error}\n\n"
                                       "Make sure:\n"
                                       "1. FlashLearn server is running on localhost:3000\n"
                                       "2. The server is accessible")
                self.status.config(text=f"❌ FlashLearn connection failed: {error}", fg=self.colors['error'])
        except Exception as e:
            logger.error(f"Error testing FlashLearn connection: {e}", exc_info=True)
            messagebox.showerror("Error", f"Error testing connection:\n{str(e)}")

    def _flashlearn_login_dialog(self):
        """Show FlashLearn login dialog with device authorization"""
        dialog = tk.Toplevel(self.root)
        dialog.title("FlashLearn Login")
        dialog.geometry("500x400")
        dialog.configure(bg=self.colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() - 500) // 2
        y = (dialog.winfo_screenheight() - 400) // 2
        dialog.geometry(f"+{x}+{y}")
        
        # Title
        tk.Label(dialog, text="🔐 FlashLearn Login", bg=self.colors['bg'], 
                fg=self.colors['accent'], font=('Segoe UI', 16, 'bold')).pack(pady=20)
        
        # Instructions frame
        instructions_frame = tk.Frame(dialog, bg=self.colors['card'], padx=20, pady=15)
        instructions_frame.pack(fill='x', padx=20, pady=10)
        
        tk.Label(instructions_frame, text="Choose a login method:", 
                bg=self.colors['card'], fg=self.colors['fg'],
                font=('Segoe UI', 11)).pack(anchor='w', pady=(0, 10))
        
        # Option 1: Browser Authorization
        browser_frame = tk.Frame(dialog, bg=self.colors['card'], padx=20, pady=15)
        browser_frame.pack(fill='x', padx=20, pady=5)
        
        tk.Label(browser_frame, text="Option 1: Browser Authorization (Recommended)", 
                bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        tk.Label(browser_frame, text="Opens browser to authorize this device", 
                bg=self.colors['card'], fg=self.colors['fg'],
                font=('Segoe UI', 9)).pack(anchor='w')
        
        def start_browser_auth():
            dialog.destroy()
            self._start_device_authorization()
        
        tk.Button(browser_frame, text="🌐 Open Browser to Login", 
                 command=start_browser_auth,
                 bg=self.colors['accent'], fg='#1e1e2e',
                 font=('Segoe UI', 10, 'bold'), padx=20, pady=8,
                 cursor='hand2').pack(pady=10)
        
        # Option 2: Manual Token Entry
        token_frame = tk.Frame(dialog, bg=self.colors['card'], padx=20, pady=15)
        token_frame.pack(fill='x', padx=20, pady=5)
        
        tk.Label(token_frame, text="Option 2: Manual Token Entry", 
                bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        tk.Label(token_frame, text="Paste a JWT token if you have one", 
                bg=self.colors['card'], fg=self.colors['fg'],
                font=('Segoe UI', 9)).pack(anchor='w')
        
        token_entry = tk.Entry(token_frame, width=50, font=('Consolas', 9))
        token_entry.pack(pady=5, fill='x')
        
        def save_manual_token():
            token = token_entry.get().strip()
            if token:
                global _flashlearn_token
                _flashlearn_token = token
                flashlearn_save_token(token)
                if flashlearn_is_authenticated():
                    messagebox.showinfo("Success", "✅ Token saved and verified!")
                    dialog.destroy()
                    self.status.config(text="✅ FlashLearn authenticated!", fg=self.colors['success'])
                else:
                    messagebox.showerror("Invalid Token", "❌ Token is invalid or expired.")
            else:
                messagebox.showwarning("No Token", "Please enter a token.")
        
        tk.Button(token_frame, text="💾 Save Token", 
                 command=save_manual_token,
                 bg=self.colors['card'], fg=self.colors['fg'],
                 font=('Segoe UI', 9), padx=15, pady=5,
                 cursor='hand2').pack(pady=5)
        
        # Cancel button
        tk.Button(dialog, text="Cancel", command=dialog.destroy,
                 bg=self.colors['card'], fg=self.colors['fg'],
                 font=('Segoe UI', 10), padx=20, pady=5,
                 cursor='hand2').pack(pady=20)

    def _start_device_authorization(self):
        """Start the device authorization flow"""
        self.status.config(text="Starting device authorization...", fg=self.colors['accent'])
        self.root.update()
        
        # Get device code
        auth_data = flashlearn_device_auth_start()
        if not auth_data:
            messagebox.showerror("Error", "Failed to start device authorization.\nMake sure FlashLearn server is running.")
            return
        
        user_code = auth_data['user_code']
        device_code = auth_data['device_code']
        verification_uri = auth_data.get('verification_uri', f"{FLASHLEARN_BASE_URL}/authorize/{user_code}")
        
        # Show dialog with code and open browser
        self._show_device_auth_dialog(user_code, device_code, verification_uri)

    def _show_device_auth_dialog(self, user_code, device_code, verification_uri):
        """Show device authorization dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Device Authorization")
        dialog.geometry("450x350")
        dialog.configure(bg=self.colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() - 450) // 2
        y = (dialog.winfo_screenheight() - 350) // 2
        dialog.geometry(f"+{x}+{y}")
        
        tk.Label(dialog, text="🔐 Authorize This Device", bg=self.colors['bg'],
                fg=self.colors['accent'], font=('Segoe UI', 14, 'bold')).pack(pady=20)
        
        tk.Label(dialog, text="A browser window has opened.\n\n1. Log in to FlashLearn (if not already)\n2. Click the 'Authorize' button on the page\n3. This dialog will close automatically",
                bg=self.colors['bg'], fg=self.colors['fg'],
                font=('Segoe UI', 11), justify='center').pack(pady=10)
        
        # Open browser button (in case it didn't open)
        def open_browser():
            import webbrowser
            webbrowser.open(verification_uri)
        
        tk.Button(dialog, text="🌐 Open Browser Again", command=open_browser,
                 bg=self.colors['card'], fg=self.colors['fg'],
                 font=('Segoe UI', 10), cursor='hand2', padx=15, pady=5).pack(pady=15)
        
        # Status label
        status_label = tk.Label(dialog, text="Waiting for authorization...",
                               bg=self.colors['bg'], fg=self.colors['fg'],
                               font=('Segoe UI', 10))
        status_label.pack(pady=15)
        
        # Open browser
        import webbrowser
        webbrowser.open(verification_uri)
        
        # Polling
        polling = {'active': True}
        
        def poll_auth():
            if not polling['active']:
                return
            
            result = flashlearn_device_auth_poll(device_code)
            status = result.get('status')
            
            if status == 'success':
                polling['active'] = False
                status_label.config(text="✅ Authorization successful!", fg=self.colors['success'])
                self.status.config(text="✅ FlashLearn authenticated!", fg=self.colors['success'])
                # Execute pending action after login
                def execute_and_close():
                    dialog.destroy()
                    pending_result = flashlearn_execute_pending_action()
                    if pending_result:
                        self.status.config(text="✅ FlashLearn: Card sent successfully!", fg=self.colors['success'])
                dialog.after(1000, execute_and_close)
            elif status == 'expired':
                polling['active'] = False
                status_label.config(text="❌ Code expired. Please try again.", fg=self.colors['error'])
            elif status == 'denied':
                polling['active'] = False
                status_label.config(text="❌ Authorization denied.", fg=self.colors['error'])
            elif status == 'pending':
                status_label.config(text="⏳ Waiting for authorization...")
                dialog.after(3000, poll_auth)
            else:
                dialog.after(3000, poll_auth)
        
        # Start polling after a short delay
        dialog.after(2000, poll_auth)
        
        def on_close():
            polling['active'] = False
            dialog.destroy()
        
        dialog.protocol("WM_DELETE_WINDOW", on_close)
        
        # Cancel button
        tk.Button(dialog, text="Cancel", command=on_close,
                 bg=self.colors['card'], fg=self.colors['fg'],
                 font=('Segoe UI', 10), padx=20, pady=5,
                 cursor='hand2').pack(pady=10)

    def _get_flashlearn_send_func(self, mode_name):
        """Get the appropriate FlashLearn send function based on mode name"""
        # Normalize mode_name for matching (remove spaces around arrows)
        normalized = mode_name.replace(" → ", "→").replace(" -> ", "→").replace("->", "→")
        logger.debug(f"Getting FlashLearn func for mode: {mode_name} (normalized: {normalized})")
        
        # Check for key patterns
        if "Audio→Image" in normalized:
            return add_audio_to_image_card_flashlearn
        elif "Image→Audio" in normalized:
            return add_image_to_audio_card_flashlearn
        elif "Both" in normalized:
            return add_both_direction_cards_flashlearn
        elif "GIF" in normalized:
            return add_audio_to_gif_card_flashlearn
        elif "Screenshots" in normalized:
            return add_audio_to_screenshots_card_flashlearn
        
        logger.warning(f"No FlashLearn function found for mode: {mode_name}")
        return None

    def _send_to_flashlearn_with_auth(self, flashlearn_func, audio_path, media_path, deck_name, notes=""):
        """
        Send to FlashLearn with authentication check.
        If not authenticated, block the action, open browser login, and resume after login.
        """
        # Check if authenticated
        if flashlearn_is_authenticated():
            # Already authenticated - send immediately
            logger.info("FlashLearn authenticated - sending immediately")
            result = flashlearn_func(audio_path, media_path, deck_name, notes)
            return result
        else:
            # Not authenticated - store pending action and open login
            logger.info("FlashLearn not authenticated - opening login")
            self.status.config(text="🔐 FlashLearn login required...", fg=self.colors['accent'])
            
            # Store the action to execute after login
            flashlearn_set_pending_action(flashlearn_func, audio_path, media_path, deck_name, notes)
            
            # Start device authorization (opens browser)
            self._start_device_authorization()
            
            # Return None - action will be executed after login completes
            return None

    def _open_settings_window(self):
        """Open the Settings window with tabbed interface"""
        # Check if settings window already exists
        if hasattr(self, 'settings_window') and self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.lift()
            self.settings_window.focus_force()
            return
        
        # Create settings window
        self.settings_window = tk.Toplevel(self.root)
        self.settings_window.title("Settings")
        self.settings_window.geometry("700x600")
        self.settings_window.configure(bg=self.colors['bg'])
        self.settings_window.transient(self.root)
        
        # Create notebook (tabbed interface)
        notebook = ttk.Notebook(self.settings_window)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Style for notebook - only change color on selection, not size
        style = ttk.Style()
        style.configure('TNotebook', background=self.colors['bg'])
        style.configure('TNotebook.Tab', padding=[15, 8], font=('Segoe UI', 10))
        style.map('TNotebook.Tab',
                  background=[('selected', self.colors['accent']), ('!selected', self.colors['card'])],
                  foreground=[('selected', '#1e1e2e'), ('!selected', self.colors['fg'])])
        
        # === GENERAL TAB ===
        general_frame = tk.Frame(notebook, bg=self.colors['card'])
        notebook.add(general_frame, text="General")
        self._build_general_tab(general_frame)
        
        # === INPUT & CAPTURE TAB === (renamed, includes Audio Device)
        capture_frame = tk.Frame(notebook, bg=self.colors['card'])
        notebook.add(capture_frame, text="Input & Capture")
        self._build_capture_tab(capture_frame)
        
        # === TIMING & MEDIA TAB === (renamed from Screenshots/GIF, includes Audio Balance)
        timing_frame = tk.Frame(notebook, bg=self.colors['card'])
        notebook.add(timing_frame, text="Timing & Media")
        self._build_timing_tab(timing_frame)
        
        # === HOTKEYS TAB ===
        hotkeys_frame = tk.Frame(notebook, bg=self.colors['card'])
        notebook.add(hotkeys_frame, text="Hotkeys")
        self._build_hotkeys_tab(hotkeys_frame)
        
        # === EDITOR TAB ===
        editor_frame = tk.Frame(notebook, bg=self.colors['card'])
        notebook.add(editor_frame, text="Editor")
        self._build_editor_tab(editor_frame)
        
        # === CONNECTIONS TAB ===
        connections_frame = tk.Frame(notebook, bg=self.colors['card'])
        notebook.add(connections_frame, text="Connections")
        self._build_connections_tab(connections_frame)
        
        # Bottom buttons frame
        buttons_frame = tk.Frame(self.settings_window, bg=self.colors['bg'])
        buttons_frame.pack(fill='x', padx=10, pady=(0, 10))
        
        tk.Button(buttons_frame, text="Save Settings", command=self._apply_settings,
                  bg=self.colors['accent'], fg='#1e1e2e', font=('Segoe UI', 10, 'bold'),
                  padx=20, pady=8).pack(side='left', padx=(0, 10))
        
        tk.Button(buttons_frame, text="Close", command=self.settings_window.destroy,
                  bg=self.colors['card'], fg=self.colors['fg'], font=('Segoe UI', 10),
                  padx=20, pady=8).pack(side='right')

    def _build_general_tab(self, parent):
        """Build General settings tab"""
        inner = tk.Frame(parent, bg=self.colors['card'])
        inner.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Deck Name
        tk.Label(inner, text="Deck Name", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        tk.Entry(inner, textvariable=self.deck_name, font=('Segoe UI', 10),
                bg=self.colors['bg'], fg=self.colors['fg'], insertbackground=self.colors['fg']
                ).pack(fill='x', pady=(0, 15))
        
        # Export Mode
        tk.Label(inner, text="Export Mode", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        export_combo = ttk.Combobox(inner, values=["Send to Anki", "Send to FlashLearn", "Export to .apkg"],
                                    textvariable=self.export_mode, state="readonly", font=('Segoe UI', 10))
        export_combo.pack(fill='x', pady=(0, 15))
        
        # Duration
        tk.Label(inner, text="Capture Duration (seconds)", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        tk.Entry(inner, textvariable=self.seconds, font=('Segoe UI', 10),
                bg=self.colors['bg'], fg=self.colors['fg'], insertbackground=self.colors['fg']
                ).pack(fill='x', pady=(0, 15))

    def _build_capture_tab(self, parent):
        """Build Input & Capture settings tab"""
        inner = tk.Frame(parent, bg=self.colors['card'])
        inner.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Audio Device (moved from Audio tab)
        tk.Label(inner, text="Audio Device", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        device_combo = ttk.Combobox(inner, values=self.devices, textvariable=self.selected_device,
                                    state="readonly", font=('Segoe UI', 10))
        device_combo.pack(fill='x', pady=(0, 15))
        
        # Monitor Selection
        tk.Label(inner, text="Monitor", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        monitor_labels = self._build_monitor_options()
        monitor_combo = ttk.Combobox(inner, values=monitor_labels, textvariable=self.monitor_label_var,
                                     state="readonly", font=('Segoe UI', 10))
        monitor_combo.pack(fill='x', pady=(0, 15))
        
        # Screenshot Region
        tk.Label(inner, text="Screenshot Region", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 10))
        
        region_frame = tk.Frame(inner, bg=self.colors['card'])
        region_frame.pack(fill='x', pady=(0, 15))
        
        tk.Radiobutton(region_frame, text="Full Screen", variable=self.region_mode, value="full",
                      command=self._on_region_mode_change, bg=self.colors['card'], fg=self.colors['fg'],
                      selectcolor=self.colors['bg'], activebackground=self.colors['card'],
                      font=('Segoe UI', 10)).pack(anchor='w')
        tk.Radiobutton(region_frame, text="Custom Area", variable=self.region_mode, value="area",
                      command=self._on_region_mode_change, bg=self.colors['card'], fg=self.colors['fg'],
                      selectcolor=self.colors['bg'], activebackground=self.colors['card'],
                      font=('Segoe UI', 10)).pack(anchor='w')
        
        self.settings_select_area_btn = tk.Button(inner, text="📐 Select Area", command=self._select_region,
                  bg=self.colors['accent'], fg='#1e1e2e', font=('Segoe UI', 10, 'bold'),
                  padx=15, pady=5)
        if self.use_region.get():
            self.settings_select_area_btn.pack(anchor='w', pady=(0, 15))

    def _build_timing_tab(self, parent):
        """Build Timing & Media settings tab (combines Audio Balance + Screenshots/GIF)"""
        inner = tk.Frame(parent, bg=self.colors['card'])
        inner.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Audio Balance Slider (moved from Audio tab)
        tk.Label(inner, text="Audio Balance (Before/After Click)", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        
        self.settings_audio_slider_label = tk.Label(inner, text="", bg=self.colors['card'], fg=self.colors['fg'],
                                                    font=('Segoe UI', 9))
        self.settings_audio_slider_label.pack(anchor='w', pady=(0, 5))
        
        self.settings_audio_slider = tk.Scale(inner, from_=0, to=self.seconds.get(),
                                              resolution=0.1, orient='horizontal',
                                              variable=self.audio_before_seconds,
                                              bg=self.colors['card'], fg=self.colors['fg'],
                                              troughcolor=self.colors['accent'],
                                              highlightthickness=0,
                                              command=self._update_settings_audio_label,
                                              showvalue=0, length=400)
        self.settings_audio_slider.pack(fill='x', pady=(0, 20))
        self._update_settings_audio_label()
        
        # Screenshot Timing
        tk.Label(inner, text="Screenshot Timing (relative to click)", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        
        self.settings_screenshot_slider_label = tk.Label(inner, text="", bg=self.colors['card'], fg=self.colors['fg'],
                                                         font=('Segoe UI', 9))
        self.settings_screenshot_slider_label.pack(anchor='w', pady=(0, 5))
        
        self.settings_screenshot_slider = tk.Scale(inner, from_=-self.seconds.get(), to=self.seconds.get(),
                                                   resolution=0.1, orient='horizontal',
                                                   variable=self.screenshot_offset_seconds,
                                                   bg=self.colors['card'], fg=self.colors['fg'],
                                                   troughcolor=self.colors['accent'],
                                                   highlightthickness=0,
                                                   command=self._update_settings_screenshot_label,
                                                   showvalue=0, length=400)
        self.settings_screenshot_slider.pack(fill='x', pady=(0, 20))
        self._update_settings_screenshot_label()
        
        # Screenshot Interval
        tk.Label(inner, text="Screenshot Interval (for multi-screenshot modes)", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        
        self.settings_interval_label = tk.Label(inner, text="", bg=self.colors['card'], fg=self.colors['fg'],
                                                font=('Segoe UI', 9))
        self.settings_interval_label.pack(anchor='w', pady=(0, 5))
        
        self.settings_interval_slider = tk.Scale(inner, from_=0.1, to=self.seconds.get(),
                                                 resolution=0.1, orient='horizontal',
                                                 variable=self.screenshot_interval,
                                                 bg=self.colors['card'], fg=self.colors['fg'],
                                                 troughcolor=self.colors['accent'],
                                                 highlightthickness=0,
                                                 command=self._update_settings_interval_label,
                                                 showvalue=0, length=400)
        self.settings_interval_slider.pack(fill='x', pady=(0, 20))
        self._update_settings_interval_label()
        
        # GIF Speed
        tk.Label(inner, text="GIF Playback Speed", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 5))
        
        self.settings_gif_label = tk.Label(inner, text="", bg=self.colors['card'], fg=self.colors['fg'],
                                           font=('Segoe UI', 9))
        self.settings_gif_label.pack(anchor='w', pady=(0, 5))
        
        self.settings_gif_slider = tk.Scale(inner, from_=100, to=2000,
                                            resolution=50, orient='horizontal',
                                            variable=self.gif_speed_ms,
                                            bg=self.colors['card'], fg=self.colors['fg'],
                                            troughcolor=self.colors['accent'],
                                            highlightthickness=0,
                                            command=self._update_settings_gif_label,
                                            showvalue=0, length=400)
        self.settings_gif_slider.pack(fill='x', pady=(0, 15))
        self._update_settings_gif_label()

    def _build_hotkeys_tab(self, parent):
        """Build Hotkeys settings tab"""
        inner = tk.Frame(parent, bg=self.colors['card'])
        inner.pack(fill='both', expand=True, padx=20, pady=20)
        
        tk.Label(inner, text="Click a button and press a key to set the hotkey",
                bg=self.colors['card'], fg=self.colors['fg'],
                font=('Segoe UI', 9, 'italic')).pack(anchor='w', pady=(0, 20))
        
        hotkeys = [
            ("Audio → Image", self.hotkey_audio_to_image),
            ("Image → Audio", self.hotkey_image_to_audio),
            ("Both Directions", self.hotkey_both_directions),
            ("Audio → GIF", self.hotkey_audio_to_video),
            ("Audio → Screenshots", self.hotkey_audio_to_screenshots),
        ]
        
        for label, var in hotkeys:
            row = tk.Frame(inner, bg=self.colors['card'])
            row.pack(fill='x', pady=(0, 10))
            
            tk.Label(row, text=label, bg=self.colors['card'], fg=self.colors['fg'],
                    font=('Segoe UI', 10), width=20, anchor='w').pack(side='left')
            
            self._create_settings_hotkey_button(row, var)

    def _build_editor_tab(self, parent):
        """Build Editor settings tab"""
        inner = tk.Frame(parent, bg=self.colors['card'])
        inner.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Show Editor Panel
        tk.Checkbutton(inner, text="Show Editor Panel", variable=self.show_editor_panel,
                      command=self._toggle_editor_panel, bg=self.colors['card'], fg=self.colors['fg'],
                      selectcolor=self.colors['bg'], activebackground=self.colors['card'],
                      font=('Segoe UI', 10)).pack(anchor='w', pady=(0, 10))
        
        # Multi-Capture Mode
        tk.Checkbutton(inner, text="Multi-Capture Mode", variable=self.editor_mode,
                      command=self._on_editor_mode_toggle, bg=self.colors['card'], fg=self.colors['fg'],
                      selectcolor=self.colors['bg'], activebackground=self.colors['card'],
                      font=('Segoe UI', 10)).pack(anchor='w', pady=(0, 20))
        
        # Editor Layout
        tk.Label(inner, text="Editor Layout", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 10, 'bold')).pack(anchor='w', pady=(0, 10))
        
        layout_frame = tk.Frame(inner, bg=self.colors['card'])
        layout_frame.pack(anchor='w')
        
        tk.Radiobutton(layout_frame, text="Side", variable=self.editor_layout, value="side",
                      command=self._change_editor_layout, bg=self.colors['card'], fg=self.colors['fg'],
                      selectcolor=self.colors['bg'], activebackground=self.colors['card'],
                      font=('Segoe UI', 10)).pack(side='left', padx=(0, 20))
        tk.Radiobutton(layout_frame, text="Bottom", variable=self.editor_layout, value="bottom",
                      command=self._change_editor_layout, bg=self.colors['card'], fg=self.colors['fg'],
                      selectcolor=self.colors['bg'], activebackground=self.colors['card'],
                      font=('Segoe UI', 10)).pack(side='left')

    def _build_connections_tab(self, parent):
        """Build Connections settings tab for Anki and FlashLearn"""
        inner = tk.Frame(parent, bg=self.colors['card'])
        inner.pack(fill='both', expand=True, padx=20, pady=20)
        
        # === ANKI SECTION ===
        tk.Label(inner, text="Anki Connection", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 12, 'bold')).pack(anchor='w', pady=(0, 10))
        
        anki_frame = tk.Frame(inner, bg=self.colors['card'])
        anki_frame.pack(fill='x', pady=(0, 20))
        
        tk.Label(anki_frame, text="Anki works automatically via AnkiConnect.\nNo login required.",
                bg=self.colors['card'], fg=self.colors['fg'], font=('Segoe UI', 9)).pack(anchor='w')
        
        tk.Button(anki_frame, text="🔗 Test Anki Connection", command=self.test_anki,
                 bg=self.colors['card'], fg=self.colors['fg'], font=('Segoe UI', 10),
                 padx=15, pady=5, cursor='hand2').pack(anchor='w', pady=(10, 0))
        
        # Separator
        ttk.Separator(inner, orient='horizontal').pack(fill='x', pady=15)
        
        # === FLASHLEARN SECTION ===
        tk.Label(inner, text="FlashLearn Connection", bg=self.colors['card'], fg=self.colors['accent'],
                font=('Segoe UI', 12, 'bold')).pack(anchor='w', pady=(0, 10))
        
        flashlearn_frame = tk.Frame(inner, bg=self.colors['card'])
        flashlearn_frame.pack(fill='x', pady=(0, 10))
        
        # Status label
        self.flashlearn_status_label = tk.Label(flashlearn_frame, text="Checking...",
                bg=self.colors['card'], fg=self.colors['fg'], font=('Segoe UI', 9))
        self.flashlearn_status_label.pack(anchor='w')
        
        # Update status
        self._update_flashlearn_status()
        
        # Buttons frame
        btn_frame = tk.Frame(inner, bg=self.colors['card'])
        btn_frame.pack(fill='x', pady=(10, 0))
        
        tk.Button(btn_frame, text="🔐 Login to FlashLearn", command=self._flashlearn_login_from_settings,
                 bg=self.colors['accent'], fg='#1e1e2e', font=('Segoe UI', 10, 'bold'),
                 padx=15, pady=8, cursor='hand2').pack(side='left', padx=(0, 10))
        
        tk.Button(btn_frame, text="🔄 Refresh Status", command=self._update_flashlearn_status,
                 bg=self.colors['card'], fg=self.colors['fg'], font=('Segoe UI', 10),
                 padx=15, pady=8, cursor='hand2').pack(side='left', padx=(0, 10))
        
        tk.Button(btn_frame, text="🚪 Logout", command=self._flashlearn_logout,
                 bg=self.colors['card'], fg=self.colors['fg'], font=('Segoe UI', 10),
                 padx=15, pady=8, cursor='hand2').pack(side='left')

    def _update_flashlearn_status(self):
        """Update FlashLearn connection status label"""
        if not hasattr(self, 'flashlearn_status_label'):
            return
        
        # First check if we have a token at all
        token = flashlearn_get_token()
        if not token:
            self.flashlearn_status_label.config(
                text="❌ Not logged in",
                fg=self.colors['error']
            )
            return
        
        # We have a token, check if it's valid in background
        self.flashlearn_status_label.config(
            text="🔄 Checking authentication...",
            fg=self.colors['fg']
        )
        self.root.update()
        
        def check_auth():
            try:
                if flashlearn_is_authenticated():
                    self.flashlearn_status_label.config(
                        text="✅ Connected and authenticated",
                        fg=self.colors['success']
                    )
                else:
                    self.flashlearn_status_label.config(
                        text="⚠️ Token expired or invalid",
                        fg=self.colors['warning']
                    )
            except Exception as e:
                logger.error(f"Error checking FlashLearn auth: {e}")
                self.flashlearn_status_label.config(
                    text="⚠️ Could not verify (server offline?)",
                    fg=self.colors['warning']
                )
        
        # Run check after a short delay to not block UI
        self.root.after(100, check_auth)

    def _flashlearn_login_from_settings(self):
        """Start FlashLearn login from settings"""
        self._start_device_authorization()

    def _flashlearn_logout(self):
        """Logout from FlashLearn"""
        flashlearn_clear_token()
        self._update_flashlearn_status()
        self.status.config(text="Logged out from FlashLearn", fg=self.colors['fg'])

    def _create_settings_hotkey_button(self, parent, hotkey_var):
        """Create a hotkey button for settings window"""
        btn = tk.Button(parent, text=hotkey_var.get().upper(),
                       bg=self.colors['accent'], fg='#1e1e2e',
                       font=('Segoe UI', 10, 'bold'), width=10)
        btn.pack(side='left', padx=(10, 0))
        
        def start_capture():
            if self.capturing_hotkey:
                return
            self.capturing_hotkey = True
            old_key = hotkey_var.get()
            btn.config(text="Press key...", bg=self.colors['warning'])
            
            def on_key(event):
                if event.keysym in ('Shift_L', 'Shift_R', 'Control_L', 'Control_R', 'Alt_L', 'Alt_R'):
                    return
                new_key = event.keysym.lower()
                hotkey_var.set(new_key)
                btn.config(text=new_key.upper(), bg=self.colors['accent'])
                self.settings_window.unbind('<Key>')
                self.capturing_hotkey = False
                self._update_capture_button_labels()
            
            def on_cancel():
                btn.config(text=old_key.upper(), bg=self.colors['accent'])
                self.settings_window.unbind('<Key>')
                try:
                    self.settings_window.unbind('<Escape>')
                except:
                    pass
                self.capturing_hotkey = False
            
            self.settings_window.bind('<Key>', on_key)
            self.settings_window.bind('<Escape>', lambda e: on_cancel())
        
        btn.config(command=start_capture)

    def _update_settings_audio_label(self, val=None):
        """Update audio slider label in settings"""
        if hasattr(self, 'settings_audio_slider_label'):
            before = self.audio_before_seconds.get()
            after = self.seconds.get() - before
            self.settings_audio_slider_label.config(
                text=f"Capturing {before:.1f}s before, {after:.1f}s after click"
            )

    def _update_settings_screenshot_label(self, val=None):
        """Update screenshot slider label in settings"""
        if hasattr(self, 'settings_screenshot_slider_label'):
            offset = self.screenshot_offset_seconds.get()
            if offset < 0:
                self.settings_screenshot_slider_label.config(text=f"Screenshot taken {abs(offset):.1f}s before click")
            elif offset > 0:
                self.settings_screenshot_slider_label.config(text=f"Screenshot taken {offset:.1f}s after click")
            else:
                self.settings_screenshot_slider_label.config(text="Screenshot taken at click moment")

    def _update_settings_interval_label(self, val=None):
        """Update interval slider label in settings"""
        if hasattr(self, 'settings_interval_label'):
            interval = self.screenshot_interval.get()
            screenshots_per_sec = 1.0 / interval if interval > 0 else 0
            self.settings_interval_label.config(
                text=f"1 screenshot every {interval:.1f}s (~{screenshots_per_sec:.1f} screenshots/second)"
            )

    def _update_settings_gif_label(self, val=None):
        """Update GIF speed slider label in settings"""
        if hasattr(self, 'settings_gif_label'):
            speed_ms = self.gif_speed_ms.get()
            fps = 1000 / speed_ms
            self.settings_gif_label.config(
                text=f"{speed_ms}ms per frame (~{fps:.1f} FPS) - Higher = Slower"
            )

    def _on_region_mode_change(self):
        """Handle region mode change in settings"""
        if self.region_mode.get() == "area":
            self.use_region.set(True)
            if hasattr(self, 'settings_select_area_btn'):
                self.settings_select_area_btn.pack(anchor='w', pady=(0, 15))
            if hasattr(self, 'select_area_btn'):
                self.select_area_btn.pack(anchor='w', pady=(5, 0))
        else:
            self.use_region.set(False)
            if hasattr(self, 'settings_select_area_btn'):
                self.settings_select_area_btn.pack_forget()
            if hasattr(self, 'select_area_btn'):
                self.select_area_btn.pack_forget()
            self.screenshotter.clear_region()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TLabel', background=self.colors['bg'], foreground=self.colors['fg'])
        style.configure('Title.TLabel', font=('Segoe UI', 16, 'bold'), foreground=self.colors['accent'])
        style.configure('TCombobox', fieldbackground=self.colors['card'], background=self.colors['card'])

    def _create_card(self, parent):
        frame = tk.Frame(parent, bg=self.colors['card'],
                         highlightbackground=self.colors['border'], highlightthickness=1)
        return frame

    def _create_labeled_field(self, parent, label_text, widget_type, **kwargs):
        container = tk.Frame(parent, bg=self.colors['card'])
        label = tk.Label(container, text=label_text, bg=self.colors['card'],
                         fg=self.colors['fg'], anchor='w', font=('Segoe UI', 9))
        label.pack(anchor='w', pady=(0, 5))
        if widget_type == 'combobox':
            widget = ttk.Combobox(container, **kwargs)
            widget.pack(fill='x', pady=(0, 10))
        elif widget_type == 'entry':
            widget = tk.Entry(container, bg=self.colors['card'], fg=self.colors['fg'],
                              insertbackground=self.colors['fg'], relief='flat',
                              highlightbackground=self.colors['border'], highlightthickness=1,
                              **kwargs)
            widget.pack(fill='x', pady=(0, 10))
        else:
            widget = None
        return container, widget
    
    def _create_hotkey_button_compact(self, parent, label_text, hotkey_var):
        """Create a single clickable button that captures hotkey on click"""
        container = tk.Frame(parent, bg=self.colors['card'])
        container.pack(side='left', fill='x', expand=True, padx=(0, 8))
        
        # Label
        label = tk.Label(container, text=f"{label_text}:",
                        bg=self.colors['card'], fg=self.colors['fg'],
                        font=('Segoe UI', 9), anchor='w')
        label.pack(anchor='w', pady=(0, 3))
        
        # Single clickable button showing current hotkey
        hotkey_btn = tk.Button(container, text=hotkey_var.get().upper(),
                              bg=self.colors['accent'], fg='#1e1e2e',
                              font=('Segoe UI', 9, 'bold'), padx=20, pady=5,
                              relief='raised', bd=2)
        
        def start_capture(event=None):
            # Prevent any default button action
            self.capturing_hotkey = True
            old_key = hotkey_var.get()
            hotkey_btn.config(text="Press key...", bg=self.colors['hover'])
            self.root.update()
            
            def on_key(key_event):
                key = key_event.keysym.lower()
                # Always unbind and reset flag first
                self.root.unbind('<Key>')
                self.root.unbind('<Escape>')
                self.capturing_hotkey = False
                
                # Only update if key actually changed
                if key != old_key:
                    hotkey_var.set(key)
                    hotkey_btn.config(text=key.upper(), bg=self.colors['accent'])
                    self._update_capture_button_labels()
                else:
                    # Key didn't change, just restore display
                    hotkey_btn.config(text=old_key.upper(), bg=self.colors['accent'])
                
                return 'break'
            
            def on_cancel():
                # Cancel hotkey capture
                hotkey_btn.config(text=old_key.upper(), bg=self.colors['accent'])
                self.root.unbind('<Key>')
                try:
                    self.root.unbind('<Escape>')
                except:
                    pass
                self.capturing_hotkey = False
            
            self.root.bind('<Key>', on_key)
            self.root.bind('<Escape>', lambda e: on_cancel())
            return 'break'  # Prevent any further event propagation
        
        hotkey_btn.config(command=start_capture)
        hotkey_btn.pack(fill='x')

    def _update_audio_slider_label(self, val=None):
        before = self.audio_before_seconds.get()
        after = self.seconds.get() - before
        self.audio_slider_label.config(
            text=f"Capturing {before:.1f}s before, {after:.1f}s after click"
        )

    def _update_screenshot_slider_label(self, val=None):
        offset = self.screenshot_offset_seconds.get()
        if offset < 0:
            self.screenshot_slider_label.config(text=f"Screenshot taken {abs(offset):.1f}s before click")
        elif offset > 0:
            self.screenshot_slider_label.config(text=f"Screenshot taken {offset:.1f}s after click")
        else:
            self.screenshot_slider_label.config(text="Screenshot taken at click moment")

    def _update_gif_speed_label(self, val=None):
        speed_ms = self.gif_speed_ms.get()
        fps = 1000 / speed_ms
        self.gif_speed_label.config(
            text=f"{speed_ms}ms per frame (~{fps:.1f} FPS) - Higher = Slower, easier to read"
        )
    
    def _update_screenshot_interval_label(self, val=None):
        interval = self.screenshot_interval.get()
        screenshots_per_sec = 1.0 / interval if interval > 0 else 0
        self.screenshot_interval_label.config(
            text=f"1 screenshot every {interval:.1f}s (~{screenshots_per_sec:.1f} screenshots/second)"
        )
    
    def _update_capture_button_labels(self):
        """Update all capture button labels when hotkeys change"""
        for btn, hotkey_var, label_text in self.capture_buttons:
            btn.config(text=f"{label_text} [{hotkey_var.get().upper()}]")

    def _on_duration_change(self, *args):
        """Update slider ranges when duration changes"""
        duration = self.seconds.get()

        # Update audio slider
        current_before = self.audio_before_seconds.get()
        if current_before > duration:
            self.audio_before_seconds.set(duration)
        self.audio_slider.config(to=duration)

        # Update screenshot slider
        current_offset = self.screenshot_offset_seconds.get()
        if abs(current_offset) > duration:
            self.screenshot_offset_seconds.set(0)
        self.screenshot_slider.config(from_=-duration, to=duration)
        
        # Update screenshot interval slider max
        current_interval = self.screenshot_interval.get()
        if current_interval > duration:
            self.screenshot_interval.set(duration)
        self.screenshot_interval_slider.config(to=duration)
        self._update_screenshot_interval_label()

        # Update buffer (make it bigger to support delays)
        max_buffer_size = max(60, duration * 3)
        self.rbuf.set_seconds(max_buffer_size)

        self._update_audio_slider_label()
        self._update_screenshot_slider_label()

    def _build_monitor_options(self):
        """Build monitor labels like 'Monitor 1 (1920x1080)'"""
        self.monitor_label_to_index = {}
        labels = []
        try:
            with mss.mss() as sct:
                monitors = sct.monitors[1:]  # skip virtual 0
                if not monitors:
                    labels = ["Monitor 1 (Unknown)"]
                    self.monitor_label_to_index[labels[0]] = 1
                    return labels

                for i, mon in enumerate(monitors, start=1):
                    w = mon.get("width", 0)
                    h = mon.get("height", 0)
                    label = f"Monitor {i} ({w}x{h})"
                    labels.append(label)
                    self.monitor_label_to_index[label] = i
        except Exception as e:
            logger.error(f"Error reading monitors: {e}", exc_info=True)
            labels = ["Monitor 1 (Unknown)"]
            self.monitor_label_to_index[labels[0]] = 1

        # pick default label matching stored index
        default_index = self.monitor_index.get()
        default_label = None
        for label, idx in self.monitor_label_to_index.items():
            if idx == default_index:
                default_label = label
                break
        if default_label is None and labels:
            default_label = labels[0]
            self.monitor_index.set(self.monitor_label_to_index[default_label])

        if default_label:
            self.monitor_label_var.set(default_label)

        return labels

    def _build_ui(self):
        # Menu bar
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Settings", command=self._open_settings_window)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.on_closing)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="Test Anki Connection", command=self.test_anki)
        help_menu.add_command(label="Test FlashLearn Connection", command=self.test_flashlearn)
        
        # Initialize region_mode variable here (needed for settings window)
        self.region_mode = tk.StringVar(value="full" if not self.use_region.get() else "area")
        
        # Main container - single frame (no paned window)
        self.main_container = tk.Frame(self.root, bg=self.colors['bg'])
        self.main_container.pack(fill='both', expand=True)
        
        # Main content panel
        left_panel = tk.Frame(self.main_container, bg=self.colors['bg'])
        
        # Header
        header = tk.Frame(left_panel, bg=self.colors['bg'])
        header.pack(fill='x', padx=25, pady=(20, 10))

        title_frame = tk.Frame(header, bg=self.colors['bg'])
        title_frame.pack(fill='x')

        tk.Label(title_frame, text="🎯 Anki Capture Studio", bg=self.colors['bg'],
                 fg=self.colors['accent'], font=('Segoe UI', 18, 'bold')).pack(side='left')
        

        # Main content frame
        main = tk.Frame(left_panel, bg=self.colors['bg'])
        main.pack(fill='both', expand=True, padx=25)
        
        # Initialize editor variables here (needed before settings window)
        self.show_editor_panel = tk.BooleanVar(value=self.show_editor_panel_default)
        self.editor_layout = tk.StringVar(value=self.editor_layout_default)
        self.editor_mode = tk.BooleanVar(value=self.editor_mode_default)

        # CAPTURE BUTTONS
        capture_label = tk.Label(main, text="🎯 CAPTURE MODES:",
                                 bg=self.colors['bg'], fg=self.colors['accent'],
                                 anchor='w', font=('Segoe UI', 11, 'bold'))
        capture_label.pack(anchor='w', pady=(5, 10))

        # All capture buttons on one line
        capture_row = tk.Frame(main, bg=self.colors['bg'])
        capture_row.pack(fill='x', pady=2)

        btn1 = tk.Button(capture_row,
                         text=f"Audio → Image [{self.hotkey_audio_to_image.get().upper()}]",
                         command=lambda: threading.Thread(target=self._capture_audio_to_image, daemon=True).start(),
                         bg=self.colors['mode1'], fg='#1e1e2e', font=('Segoe UI', 8, 'bold'),
                         height=2, relief='raised', bd=1, wraplength=120)
        btn1.pack(side='left', fill='both', expand=True, padx=(0, 5))
        self.capture_buttons.append((btn1, self.hotkey_audio_to_image, "Audio → Image"))

        btn2 = tk.Button(capture_row,
                         text=f"Image → Audio [{self.hotkey_image_to_audio.get().upper()}]",
                         command=lambda: threading.Thread(target=self._capture_image_to_audio, daemon=True).start(),
                         bg=self.colors['mode2'], fg='#1e1e2e', font=('Segoe UI', 8, 'bold'),
                         height=2, relief='raised', bd=1, wraplength=120)
        btn2.pack(side='left', fill='both', expand=True, padx=(0, 5))
        self.capture_buttons.append((btn2, self.hotkey_image_to_audio, "Image → Audio"))

        btn3 = tk.Button(capture_row,
                         text=f"Both Directions [{self.hotkey_both_directions.get().upper()}]",
                         command=lambda: threading.Thread(target=self._capture_both_directions, daemon=True).start(),
                         bg=self.colors['mode3'], fg='#1e1e2e', font=('Segoe UI', 8, 'bold'),
                         height=2, relief='raised', bd=1, wraplength=120)
        btn3.pack(side='left', fill='both', expand=True, padx=(0, 5))
        self.capture_buttons.append((btn3, self.hotkey_both_directions, "Both Directions"))

        btn4 = tk.Button(capture_row,
                         text=f"Audio → GIF [{self.hotkey_audio_to_video.get().upper()}]",
                         command=lambda: threading.Thread(target=self._capture_audio_to_gif, daemon=True).start(),
                         bg=self.colors['mode5'], fg='#1e1e2e', font=('Segoe UI', 8, 'bold'),
                         height=2, relief='raised', bd=1, wraplength=120)
        btn4.pack(side='left', fill='both', expand=True, padx=(0, 5))
        self.capture_buttons.append((btn4, self.hotkey_audio_to_video, "Audio → GIF"))

        btn5 = tk.Button(capture_row,
                         text=f"Audio → Screenshots [{self.hotkey_audio_to_screenshots.get().upper()}]",
                         command=lambda: threading.Thread(target=self._capture_audio_to_screenshots, daemon=True).start(),
                         bg=self.colors['mode6'], fg='#1e1e2e', font=('Segoe UI', 8, 'bold'),
                         height=2, relief='raised', bd=1, wraplength=120)
        btn5.pack(side='left', fill='both', expand=True)
        self.capture_buttons.append((btn5, self.hotkey_audio_to_screenshots, "Audio → Screenshots"))

        # Simple horizontal divider between Capture Modes and Editor
        divider_frame = tk.Frame(main, bg=self.colors['bg'])
        divider_frame.pack(fill='x', pady=(15, 10))
        tk.Frame(divider_frame, bg=self.colors['border'], height=1).pack(fill='x')
        
        # EDITOR SECTION - embedded below capture modes (same panel)
        self.editor_section = tk.Frame(main, bg=self.colors['bg'])
        self.editor_section.pack(fill='both', expand=True)
        
        # Editor header
        editor_header = tk.Frame(self.editor_section, bg=self.colors['bg'])
        editor_header.pack(fill='x', pady=(0, 10))
        
        tk.Label(editor_header, text="📝 Editor",
                bg=self.colors['bg'], fg=self.colors['accent'],
                font=('Segoe UI', 14, 'bold')).pack(side='left')
        
        # Capture navigation frame (for Multi-Capture Mode)
        self.capture_nav_frame = tk.Frame(editor_header, bg=self.colors['bg'])
        self.capture_nav_frame.pack(side='right')
        
        # Delete button (left of prev)
        self.delete_capture_btn = tk.Button(
            self.capture_nav_frame, text="🗑️ Delete",
            command=self._delete_current_capture,
            bg=self.colors['error'], fg='#1e1e2e',
            font=('Segoe UI', 9, 'bold'), padx=10, pady=3
        )
        self.delete_capture_btn.pack(side='left', padx=(0, 15))
        
        # Navigation buttons
        self.prev_capture_btn = tk.Button(
            self.capture_nav_frame, text="◀ Prev",
            command=self._prev_capture,
            bg=self.colors['accent'], fg='#1e1e2e',
            font=('Segoe UI', 9, 'bold'), padx=10, pady=3
        )
        self.prev_capture_btn.pack(side='left', padx=2)
        
        self.capture_index_label = tk.Label(
            self.capture_nav_frame, text="0 / 0",
            bg=self.colors['bg'], fg=self.colors['fg'],
            font=('Segoe UI', 10, 'bold')
        )
        self.capture_index_label.pack(side='left', padx=10)
        
        self.next_capture_btn = tk.Button(
            self.capture_nav_frame, text="Next ▶",
            command=self._next_capture,
            bg=self.colors['accent'], fg='#1e1e2e',
            font=('Segoe UI', 9, 'bold'), padx=10, pady=3
        )
        self.next_capture_btn.pack(side='left', padx=2)
        
        # Hide navigation by default (shown when Multi-Capture Mode is active)
        self.capture_nav_frame.pack_forget()
        
        # Editor card container (matching main app style)
        editor_card = self._create_card(self.editor_section)
        editor_card.pack(fill='both', expand=True)
        
        # Editor content frame (no scrollbar)
        self.editor_content_frame = tk.Frame(editor_card, bg=self.colors['card'])
        self.editor_content_frame.pack(fill='both', expand=True, padx=20, pady=15)
        
        # Placeholder when no content
        self.editor_placeholder = tk.Label(
            self.editor_content_frame,
            text="No content yet\n\nCapture something to see it here",
            bg=self.colors['card'], fg=self.colors['fg'],
            font=('Segoe UI', 11), justify='center'
        )
        self.editor_placeholder.pack(expand=True, pady=50)
        
        # Pack left_panel to fill main container
        left_panel.pack(fill='both', expand=True)
        
        # Status bar at the very bottom of the window
        self.status_frame = tk.Frame(self.root, bg=self.colors['card'], height=30)
        self.status_frame.pack(fill='x', side='bottom')
        self.status_frame.pack_propagate(False)
        
        self.status = tk.Label(self.status_frame, text="Initializing...", bg=self.colors['card'],
                               fg=self.colors['fg'], anchor='w', justify='left',
                               font=('Segoe UI', 9), padx=15)
        self.status.pack(fill='both', expand=True)

    def _change_editor_layout(self):
        """Change editor layout - no longer needed with embedded editor"""
        pass  # Editor is now always embedded below capture modes
    
    def _toggle_editor_panel(self):
        """Show or hide the editor panel"""
        if self.show_editor_panel.get():
            self.editor_section.pack(fill='both', expand=True)
        else:
            self.editor_section.pack_forget()
    
    def _on_editor_mode_toggle(self):
        """Handle Multi-Capture Mode toggle"""
        if self.editor_mode.get():
            # Multi-Capture Mode enabled - show navigation with delete button
            self.capture_nav_frame.pack(side='right')
            # Also enable editor panel if not already
            if not self.show_editor_panel.get():
                self.show_editor_panel.set(True)
                self._toggle_editor_panel()
            self._update_capture_nav_label()
            self.status.config(text="📸 Multi-Capture Mode enabled - captures stored for review", fg=self.colors['accent'])
        else:
            # Multi-Capture Mode disabled - hide navigation
            self.capture_nav_frame.pack_forget()
            # Clear capture list
            self.editor_mode_captures = []
            self.current_capture_index = 0
            self._update_capture_nav_label()
            # Show placeholder
            self._display_current_capture()
            self.status.config(text="📸 Multi-Capture Mode disabled", fg=self.colors['fg'])
    
    def _update_capture_nav_label(self):
        """Update the capture navigation label"""
        total = len(self.editor_mode_captures)
        if total == 0:
            self.capture_index_label.config(text="0 / 0")
            self.prev_capture_btn.config(state='disabled')
            self.next_capture_btn.config(state='disabled')
        else:
            current = self.current_capture_index + 1
            self.capture_index_label.config(text=f"{current} / {total}")
            self.prev_capture_btn.config(state='normal' if self.current_capture_index > 0 else 'disabled')
            self.next_capture_btn.config(state='normal' if self.current_capture_index < total - 1 else 'disabled')
    
    def _prev_capture(self):
        """Navigate to previous capture"""
        if self.current_capture_index > 0:
            self.current_capture_index -= 1
            self._display_current_capture()
    
    def _next_capture(self):
        """Navigate to next capture"""
        if self.current_capture_index < len(self.editor_mode_captures) - 1:
            self.current_capture_index += 1
            self._display_current_capture()
    
    def _on_capture_list_select(self, index):
        """Handle capture selection from dropdown in editor"""
        if 0 <= index < len(self.editor_mode_captures):
            self.current_capture_index = index
            self._display_current_capture()
    
    def _display_current_capture(self):
        """Display the current capture in the editor"""
        if not self.editor_mode_captures:
            # No captures - show placeholder
            for widget in self.editor_content_frame.winfo_children():
                widget.destroy()
            self.editor_placeholder = tk.Label(
                self.editor_content_frame,
                text="No captures yet\n\nCapture something to see it here",
                bg=self.colors['card'], fg=self.colors['fg'],
                font=('Segoe UI', 11), justify='center'
            )
            self.editor_placeholder.pack(expand=True, pady=100)
            self._update_capture_nav_label()
            return
        
        capture = self.editor_mode_captures[self.current_capture_index]
        
        # Clear existing content
        for widget in self.editor_content_frame.winfo_children():
            widget.destroy()
        
        # Import here to avoid circular dependency
        from capture_editor import CaptureEditor
        
        # Set layout mode for editor
        layout_mode = self.editor_layout.get()
        
        # Create editor instance with callback for Send to Anki button
        editor = CaptureEditor(
            self.editor_content_frame,
            audio_path=capture['audio_path'],
            image_paths=capture['image_paths'],
            gif_path=capture.get('gif_path'),
            mode_name=capture['mode_name'],
            callback=self._on_multi_capture_send,  # Callback for Send to Anki
            gif_speed_ms=self.gif_speed_ms.get(),
            embedded=True,
            layout_mode=layout_mode
        )
        editor._create_embedded_content()
        
        # Store reference to current editor for trimming
        self.current_editor = editor
        
        self._update_capture_nav_label()
    
    def _on_multi_capture_send(self, send_confirmed, trimmed_audio, media_files):
        """Callback when Confirm & Send is clicked in Multi-Capture Mode"""
        if not send_confirmed or not self.editor_mode_captures:
            return
        
        capture = self.editor_mode_captures[self.current_capture_index]
        mode_name = capture['mode_name']
        
        try:
            # Get single media path for single-image modes
            if isinstance(media_files, list) and len(media_files) == 1:
                media_path = media_files[0]
            elif isinstance(media_files, str):
                media_path = media_files
            else:
                media_path = media_files  # Keep as list for screenshots mode
            
            export_mode = self.export_mode.get()
            
            if export_mode == "Send to Anki":
                send_func = capture['send_func']
                if send_func:
                    send_func(trimmed_audio, media_path, self.deck_name.get())
                    self.status.config(text=f"✅ {mode_name} sent to Anki!", fg=self.colors['success'])
            elif export_mode == "Send to FlashLearn":
                flashlearn_func = self._get_flashlearn_send_func(mode_name)
                if flashlearn_func:
                    # Use auth-checked send - will open login if not authenticated
                    ok = self._send_to_flashlearn_with_auth(flashlearn_func, trimmed_audio, media_path, self.deck_name.get(), "")
                    if ok:
                        self.status.config(text=f"✅ {mode_name} sent to FlashLearn!", fg=self.colors['success'])
                    # If ok is None, login was triggered - status already updated
                else:
                    self.status.config(text=f"⚠️ FlashLearn not supported for this mode.", fg=self.colors['error'])
            else:
                # Export to .apkg
                export_func = capture['export_func']
                if export_func:
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    apkg_name = f"{mode_name.replace(' ', '_').replace(':', '')}_{timestamp}.apkg"
                    apkg_path = export_func(trimmed_audio, media_path, self.deck_name.get(), apkg_name)
                    if apkg_path:
                        self.status.config(text=f"✅ {mode_name}: .apkg exported!", fg=self.colors['success'])
                    else:
                        self.status.config(text=f"⚠️ Failed to export .apkg.", fg=self.colors['error'])
        except Exception as e:
            logger.error(f"Send failed: {e}", exc_info=True)
            self.status.config(text=f"❌ Error: {str(e)}", fg=self.colors['error'])
    
    def _send_current_capture(self):
        """Send current capture based on export mode"""
        if not self.editor_mode_captures:
            return
        
        capture = self.editor_mode_captures[self.current_capture_index]
        
        try:
            # Get trimmed audio if editor has trimming
            audio_path = capture['audio_path']
            if hasattr(self, 'current_editor') and self.current_editor:
                trimmed_path = self.current_editor._apply_audio_trim()
                if trimmed_path:
                    audio_path = trimmed_path
            
            # Get media paths
            if capture.get('gif_path'):
                media_paths = capture['gif_path']  # Single path for GIF
            elif hasattr(self, 'current_editor') and self.current_editor and self.current_editor.screenshot_checkboxes:
                # Filter only checked screenshots
                media_paths = [path for path, var in self.current_editor.screenshot_checkboxes.items() if var.get()]
                if not media_paths:
                    messagebox.showwarning("No Screenshots Selected", 
                                         "Please select at least one screenshot.")
                    return
            else:
                media_paths = capture['image_paths']
            
            # Get single media path for single-image modes
            if isinstance(media_paths, list) and len(media_paths) == 1:
                media_path = media_paths[0]
            elif isinstance(media_paths, str):
                media_path = media_paths
            else:
                media_path = media_paths  # Keep as list for screenshots mode
            
            export_mode = self.export_mode.get()
            mode_name = capture['mode_name']
            
            if export_mode == "Send to Anki":
                send_func = capture['send_func']
                if send_func:
                    send_func(audio_path, media_path, self.deck_name.get())
                    self.status.config(text=f"✅ {mode_name} sent to Anki!", fg=self.colors['success'])
            elif export_mode == "Send to FlashLearn":
                flashlearn_func = self._get_flashlearn_send_func(mode_name)
                if flashlearn_func:
                    # Use auth-checked send - will open login if not authenticated
                    ok = self._send_to_flashlearn_with_auth(flashlearn_func, audio_path, media_path, self.deck_name.get(), "")
                    if ok:
                        self.status.config(text=f"✅ {mode_name} sent to FlashLearn!", fg=self.colors['success'])
                    # If ok is None, login was triggered - status already updated
                else:
                    self.status.config(text=f"⚠️ FlashLearn not supported for this mode.", fg=self.colors['error'])
            else:
                # Export to .apkg
                export_func = capture['export_func']
                if export_func:
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    apkg_name = f"{mode_name.replace(' ', '_').replace(':', '')}_{timestamp}.apkg"
                    apkg_path = export_func(audio_path, media_path, self.deck_name.get(), apkg_name)
                    if apkg_path:
                        self.status.config(text=f"✅ {mode_name}: .apkg exported!", fg=self.colors['success'])
                    else:
                        self.status.config(text=f"⚠️ Failed to export .apkg.", fg=self.colors['error'])
            
        except Exception as e:
            logger.error(f"Send failed: {e}", exc_info=True)
            self.status.config(text=f"❌ Error: {str(e)}", fg=self.colors['error'])
    
    def _delete_current_capture(self):
        """Delete current capture and move to next"""
        if not self.editor_mode_captures:
            return
        
        # Remove current capture
        del self.editor_mode_captures[self.current_capture_index]
        
        # Adjust index if needed
        if self.current_capture_index >= len(self.editor_mode_captures):
            self.current_capture_index = max(0, len(self.editor_mode_captures) - 1)
        
        # Display next capture or empty state
        self._display_current_capture()
        
        if self.editor_mode_captures:
            self.status.config(text=f"🗑️ Capture deleted. {len(self.editor_mode_captures)} remaining.", fg=self.colors['fg'])
        else:
            self.status.config(text="🗑️ All captures deleted.", fg=self.colors['fg'])
    
    def _add_capture_to_editor_mode(self, audio_path, image_paths, mode_name, send_func, export_func, gif_path=None):
        """Add a capture to the Editor Mode list"""
        capture = {
            'audio_path': audio_path,
            'image_paths': image_paths or [],
            'gif_path': gif_path,
            'mode_name': mode_name,
            'send_func': send_func,
            'export_func': export_func
        }
        self.editor_mode_captures.append(capture)
        
        # Navigate to the new capture
        self.current_capture_index = len(self.editor_mode_captures) - 1
        self._display_current_capture()
        
        self.status.config(text=f"📸 Capture added ({len(self.editor_mode_captures)} total)", fg=self.colors['success'])
    
    def _show_embedded_editor(self, audio_path, image_paths, mode_name, send_func, export_func, gif_path=None):
        """Show editor content in the embedded right panel OR send directly to Anki"""
        # If Editor Mode is active, add to capture list instead of sending
        if self.editor_mode.get():
            self._add_capture_to_editor_mode(audio_path, image_paths, mode_name, send_func, export_func, gif_path)
            return
        
        # If "Review in Editor" is unchecked, send directly to Anki
        if not self.show_editor_panel.get():
            try:
                # Send to Anki directly without editor
                if send_func:
                    send_func(audio_path, image_paths if image_paths else [gif_path] if gif_path else [], self.deck_name.get())
                    self.status.config(text=f"✅ {mode_name} sent to Anki!", fg=self.colors['success'])
                
                # Export .apkg
                if export_func:
                    timestamp = time.strftime("%Y%m%d_%H%M%S")
                    apkg_name = f"{mode_name.replace(' ', '_').replace(':', '')}_{timestamp}.apkg"
                    apkg_path = os.path.join(SAVE_DIR, apkg_name)
                    export_func(audio_path, image_paths if image_paths else [gif_path] if gif_path else [], self.deck_name.get(), apkg_path)
                    logger.info(f"Exported {apkg_path}")
            except Exception as e:
                logger.error(f"{mode_name} send failed: {e}", exc_info=True)
                self.status.config(text=f"❌ {mode_name} Error: {str(e)}", fg=self.colors['error'])
            return
        
        # Clear existing content before showing new capture
        for widget in self.editor_content_frame.winfo_children():
            widget.destroy()
        
        # Show the editor panel if not already shown
        if not self.show_editor_panel.get():
            self.show_editor_panel.set(True)
            self._toggle_editor_panel()
        
        # Import here to avoid circular dependency
        from capture_editor import CaptureEditor
        
        # Set layout mode for editor
        layout_mode = self.editor_layout.get()
        
        # Create callback for when editor is done
        def on_editor_done(send_to_anki, trimmed_audio, media_files):
            if send_to_anki:
                try:
                    # Send to Anki
                    if send_func:
                        send_func(trimmed_audio, media_files, self.deck_name.get())
                        self.status.config(text=f"✅ {mode_name} sent to Anki!", fg=self.colors['success'])
                    
                    # Export .apkg
                    if export_func:
                        timestamp = time.strftime("%Y%m%d_%H%M%S")
                        apkg_name = f"{mode_name.replace(' ', '_').replace(':', '')}_{timestamp}.apkg"
                        apkg_path = os.path.join(SAVE_DIR, apkg_name)
                        export_func(trimmed_audio, media_files, self.deck_name.get(), apkg_path)
                        logger.info(f"Exported {apkg_path}")
                except Exception as e:
                    logger.error(f"{mode_name} send failed: {e}", exc_info=True)
                    self.status.config(text=f"❌ {mode_name} Error: {str(e)}", fg=self.colors['error'])
        
        # Create editor instance but don't show window - we'll embed it
        editor = CaptureEditor(
            self.editor_content_frame,  # Use embedded frame instead of root
            audio_path=audio_path,
            image_paths=image_paths,
            gif_path=gif_path,
            mode_name=mode_name,
            callback=on_editor_done,
            gif_speed_ms=self.gif_speed_ms.get(),
            embedded=True,  # Flag to indicate embedded mode
            layout_mode=layout_mode  # Pass layout mode for horizontal/vertical arrangement
        )
        # Don't call editor.show() - instead embed directly
        editor._create_embedded_content()
    
    def _apply_settings(self):
        # Update monitor index from label
        label = self.monitor_label_var.get()
        idx = self.monitor_label_to_index.get(label, 1)
        self.monitor_index.set(idx)

        self.rec.set_device(self.selected_device.get())
        self.screenshotter.monitor_index = self.monitor_index.get()
        max_buffer_size = max(60, self.seconds.get() * 3)
        self.rbuf.set_seconds(max_buffer_size)
        
        # Apply region settings
        self._apply_region_settings()
        
        # Update screenshotter interval
        if hasattr(self, 'screenshotter'):
            self.screenshotter.interval = self.screenshot_interval.get()
            logger.info(f"Screenshot interval updated to {self.screenshot_interval.get()}s")
        
        self.save_settings()
        self.status.config(text=f"✅ Settings saved! Deck: {self.deck_name.get()}", fg=self.colors['success'])

    def _select_region(self):
        """Open region selector overlay"""
        try:
            self.status.config(text="📐 Select region by clicking and dragging...", fg=self.colors['accent'])
            self.root.update()
            
            # Minimize main window
            self.root.iconify()
            time.sleep(0.3)  # Give time for window to minimize
            
            # Create region selector
            selector = RegionSelector(self._on_region_selected)
            selector.select_region()
            
        except Exception as e:
            logger.error(f"Region selection error: {e}", exc_info=True)
            self.status.config(text=f"❌ Region selection failed: {str(e)}", fg=self.colors['error'])
            self.root.deiconify()

    def _on_region_selected(self, x, y, width, height):
        """Callback when region is selected"""
        self.root.deiconify()
        
        if x is None or width is None or width < 50 or height < 50:
            self.status.config(text="⚠️ Region selection cancelled or too small", fg=self.colors['error'])
            return
        
        # Store region coordinates
        self.region_x.set(x)
        self.region_y.set(y)
        self.region_width.set(width)
        self.region_height.set(height)
        self.use_region.set(True)
        
        # Apply to screenshotter
        self._apply_region_settings()
        
        # Update UI
        self.status.config(
            text=f"✅ Region selected: {width}x{height} at ({x}, {y})",
            fg=self.colors['success']
        )
        logger.info(f"Region selected: x={x}, y={y}, w={width}, h={height}")

    def _clear_region(self):
        """Clear region and use full monitor"""
        self.use_region.set(False)
        self.region_x.set(0)
        self.region_y.set(0)
        self.region_width.set(0)
        self.region_height.set(0)
        
        # Apply to screenshotter
        self.screenshotter.clear_region()
        
        # Update UI
        self.status.config(text="✅ Region cleared - using full monitor", fg=self.colors['success'])
        logger.info("Region cleared")

    def _on_region_toggle(self):
        """Handle region checkbox toggle"""
        self._apply_region_settings()

    def _apply_region_settings(self):
        """Apply current region settings to screenshotter"""
        if self.use_region.get() and self.region_width.get() > 0 and self.region_height.get() > 0:
            self.screenshotter.set_region(
                self.region_x.get(),
                self.region_y.get(),
                self.region_width.get(),
                self.region_height.get()
            )
        else:
            self.screenshotter.clear_region()


    def _capture_audio_and_image(self):
        """
        Immediate mode:
        - Wait 'after' seconds
        - Capture total duration (before+after) ending at that time
        - Screenshot based on click + offset
        """
        try:
            ts_click = time.time()
            logger.info(f"=== CAPTURE TRIGGERED at timestamp={ts_click:.3f} ===")

            total_duration = float(self.seconds.get())
            before_seconds = float(self.audio_before_seconds.get())
            if before_seconds < 0:
                before_seconds = 0.0
            if before_seconds > total_duration:
                before_seconds = total_duration
            after_seconds = total_duration - before_seconds
            screenshot_offset = float(self.screenshot_offset_seconds.get())

            logger.info(f"Settings: total={total_duration:.2f}s, before={before_seconds:.2f}s, after={after_seconds:.2f}s")
            logger.info(f"Screenshot offset={screenshot_offset:.2f}s")

            if after_seconds > 0:
                logger.info(f"Waiting {after_seconds:.2f}s for after portion...")
                time.sleep(after_seconds)

            capture_len = total_duration
            logger.info(f"Capturing last {capture_len:.2f}s from buffer")

            audio = self.rbuf.get_last_seconds(capture_len)
            actual_len = audio.shape[0] / float(SAMPLE_RATE) if audio.size else 0.0
            logger.info(f"Audio captured: ~{actual_len:.2f}s of audio frames")

            if audio.shape[0] == 0:
                raise RuntimeError("No audio captured. Make sure audio is playing.")

            # Screenshot timing
            screenshot_time = ts_click + screenshot_offset
            logger.info(f"Screenshot target: {screenshot_time:.3f} (click={ts_click:.3f}, offset={screenshot_offset:.2f}s)")
            img = self.screenshotter.get_at_time(screenshot_time)

            if not img:
                raise RuntimeError("No screenshot available.")

            return audio, img

        except Exception as e:
            logger.error(f"Capture failed: {e}", exc_info=True)
            raise

    def _save_files(self, audio, img, prefix):
        """Save audio and image files"""
        ts_filename = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        base = os.path.join(SAVE_DIR, f"{prefix}_{ts_filename}")
        audio_path = f"{base}.wav"
        img_path = f"{base}.jpg"

        write_wav_fast(audio_path, audio, SAMPLE_RATE)
        img.save(img_path, optimize=True, quality=80)

        logger.info(f"Files saved: {audio_path}, {img_path}")
        return audio_path, img_path

    def _show_editor_and_send(self, audio_path, media_paths, mode_name, send_func, export_func):
        """
        Show capture editor (if enabled), then send to Anki or export
        audio_path: path to audio file
        media_paths: list of image/gif paths
        mode_name: name of mode for display
        send_func: function(audio_path, media_path, deck_name, notes) to send to Anki
        export_func: function(audio_path, media_path, deck_name, apkg_name, notes) to export
        """
        # Check if editor is enabled
        if not self.use_editor.get():
            # Send directly without editor
            try:
                media_path = media_paths[0] if media_paths else None
                export_mode = self.export_mode.get()
                
                if export_mode == "Send to Anki":
                    ok = send_func(audio_path, media_path, self.deck_name.get(), "")
                    if ok:
                        self.status.config(
                            text=f"✅ {mode_name}: Card sent to {self.deck_name.get()}",
                            fg=self.colors['success']
                        )
                    else:
                        self.status.config(
                            text=f"⚠️ {mode_name}: Anki not responding. Files saved to disk.",
                            fg=self.colors['error']
                        )
                elif export_mode == "Send to FlashLearn":
                    # Get the FlashLearn send function based on mode
                    flashlearn_func = self._get_flashlearn_send_func(mode_name)
                    if flashlearn_func:
                        # Use auth-checked send - will open login if not authenticated
                        ok = self._send_to_flashlearn_with_auth(flashlearn_func, audio_path, media_path, self.deck_name.get(), "")
                        if ok:
                            self.status.config(
                                text=f"✅ {mode_name}: Card sent to FlashLearn ({self.deck_name.get()})",
                                fg=self.colors['success']
                            )
                        # If ok is None, login was triggered - status already updated
                    else:
                        self.status.config(
                            text=f"⚠️ {mode_name}: FlashLearn not supported for this mode.",
                            fg=self.colors['error']
                        )
                else:
                    apkg_path = export_func(audio_path, media_path, self.deck_name.get(), 
                                           self.apkg_audio_name.get(), "")
                    if apkg_path:
                        self.status.config(
                            text=f"✅ {mode_name}: .apkg exported: {os.path.basename(apkg_path)}",
                            fg=self.colors['success']
                        )
                    else:
                        self.status.config(
                            text=f"⚠️ {mode_name}: Failed to export .apkg. Files saved to disk.",
                            fg=self.colors['error']
                        )
            except Exception as e:
                logger.error(f"{mode_name} send failed: {e}", exc_info=True)
                self.status.config(text=f"❌ {mode_name} Error: {str(e)}", fg=self.colors['error'])
            return
        
        # Show editor if enabled
        def on_editor_done(confirmed, final_audio_path, final_media_paths, notes):
            if not confirmed:
                self.status.config(text=f"⚠️ {mode_name}: Cancelled", fg=self.colors['error'])
                return
            
            try:
                # Use the first media path (for single image/gif modes)
                media_path = final_media_paths[0] if final_media_paths else None
                export_mode = self.export_mode.get()
                
                if export_mode == "Send to Anki":
                    ok = send_func(final_audio_path, media_path, self.deck_name.get(), notes)
                    if ok:
                        self.status.config(
                            text=f"✅ {mode_name}: Card sent to {self.deck_name.get()}",
                            fg=self.colors['success']
                        )
                    else:
                        self.status.config(
                            text=f"⚠️ {mode_name}: Anki not responding. Files saved to disk.",
                            fg=self.colors['error']
                        )
                elif export_mode == "Send to FlashLearn":
                    flashlearn_func = self._get_flashlearn_send_func(mode_name)
                    if flashlearn_func:
                        # Use auth-checked send - will open login if not authenticated
                        ok = self._send_to_flashlearn_with_auth(flashlearn_func, final_audio_path, media_path, self.deck_name.get(), notes)
                        if ok:
                            self.status.config(
                                text=f"✅ {mode_name}: Card sent to FlashLearn ({self.deck_name.get()})",
                                fg=self.colors['success']
                            )
                        # If ok is None, login was triggered - status already updated
                    else:
                        self.status.config(
                            text=f"⚠️ {mode_name}: FlashLearn not supported for this mode.",
                            fg=self.colors['error']
                        )
                else:
                    apkg_path = export_func(final_audio_path, media_path, self.deck_name.get(), 
                                           self.apkg_audio_name.get(), notes)
                    if apkg_path:
                        self.status.config(
                            text=f"✅ {mode_name}: .apkg exported: {os.path.basename(apkg_path)}",
                            fg=self.colors['success']
                        )
                    else:
                        self.status.config(
                            text=f"⚠️ {mode_name}: Failed to export .apkg. Files saved to disk.",
                            fg=self.colors['error']
                        )
            except Exception as e:
                logger.error(f"{mode_name} send failed: {e}", exc_info=True)
                self.status.config(text=f"❌ {mode_name} Error: {str(e)}", fg=self.colors['error'])
        
        # Show editor in embedded panel
        self._show_embedded_editor(
            audio_path=audio_path,
            image_paths=media_paths,
            mode_name=mode_name,
            send_func=send_func,
            export_func=export_func
        )

    def _capture_audio_to_image(self):
        """MODE 1: Audio front → Image back (1 card)"""
        try:
            logger.info("MODE 1: Capturing Audio->Image")
            self.status.config(text="📸 MODE 1: Capturing audio and image...", fg=self.colors['accent'])

            audio, img = self._capture_audio_and_image()
            audio_path, img_path = self._save_files(audio, img, "mode1_audio_to_image")

            # Show editor
            self._show_editor_and_send(
                audio_path, 
                [img_path], 
                "MODE 1: Audio→Image",
                add_audio_to_image_card,
                export_audio_to_image_apkg
            )

        except Exception as e:
            logger.error(f"MODE 1 failed: {e}", exc_info=True)
            self.status.config(text=f"❌ MODE 1 Error: {str(e)}", fg=self.colors['error'])
            self.show_error("MODE 1 Failed", f"Failed to capture Audio→Image:\n\n{str(e)}")

    def _capture_image_to_audio(self):
        """MODE 2: Image front → Audio back (1 card)"""
        try:
            logger.info("MODE 2: Capturing Image->Audio")
            self.status.config(text="📸 MODE 2: Capturing image and audio...", fg=self.colors['accent'])

            audio, img = self._capture_audio_and_image()
            audio_path, img_path = self._save_files(audio, img, "mode2_image_to_audio")

            # Show editor
            self._show_editor_and_send(
                audio_path, 
                [img_path], 
                "MODE 2: Image→Audio",
                add_image_to_audio_card,
                lambda a, i, d, apkg, n: export_image_to_audio_apkg(a, i, d, apkg)
            )

        except Exception as e:
            logger.error(f"MODE 2 failed: {e}", exc_info=True)
            self.status.config(text=f"❌ MODE 2 Error: {str(e)}", fg=self.colors['error'])
            self.show_error("MODE 2 Failed", f"Failed to capture Image→Audio:\n\n{str(e)}")

    def _capture_both_directions(self):
        """MODE 3: Both directions (2 cards)"""
        try:
            logger.info("MODE 3: Capturing both directions")
            self.status.config(text="📸 MODE 3: Capturing for both directions...", fg=self.colors['accent'])

            audio, img = self._capture_audio_and_image()
            audio_path, img_path = self._save_files(audio, img, "mode3_both_directions")

            # Show editor
            self._show_editor_and_send(
                audio_path, 
                [img_path], 
                "MODE 3: Both Directions",
                add_both_direction_cards,
                lambda a, i, d, apkg, n: export_both_directions_apkg(a, i, d, apkg)
            )

        except Exception as e:
            logger.error(f"MODE 3 failed: {e}", exc_info=True)
            self.status.config(text=f"❌ MODE 3 Error: {str(e)}", fg=self.colors['error'])
            self.show_error("MODE 3 Failed", f"Failed to capture both directions:\n\n{str(e)}")

    def _capture_audio_to_gif(self):
        """MODE 4: Audio front → GIF back (1 card)"""
        try:
            logger.info("MODE 4: Capturing Audio->GIF")
            self.status.config(text="🎬 MODE 4: Creating audio and GIF...", fg=self.colors['accent'])

            total_duration = float(self.seconds.get())
            before_seconds = float(self.audio_before_seconds.get())
            if before_seconds < 0:
                before_seconds = 0.0
            if before_seconds > total_duration:
                before_seconds = total_duration
            after_seconds = total_duration - before_seconds

            logger.info(f"Waiting {after_seconds}s before capturing...")
            
            # Wait for the 'after' period (like audio capture)
            time.sleep(after_seconds)

            # Get audio from buffer (last N seconds)
            audio = self.rbuf.get_last_seconds(total_duration)
            
            if audio is None or len(audio) == 0:
                raise RuntimeError("No audio captured")

            # Get frames from rolling screenshot buffer (last N seconds)
            frames = self.screenshotter.get_frames_for_duration(total_duration)
            
            if not frames or len(frames) == 0:
                raise RuntimeError("No frames captured for GIF")

            # Save audio
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            audio_path = os.path.join(SAVE_DIR, f"audio_{timestamp}.wav")
            write_wav_fast(audio_path, audio, SAMPLE_RATE)
            logger.info(f"Audio saved: {audio_path}")

            # Create GIF from frames with custom speed
            gif_path = create_gif_from_frames(frames, total_duration, self.gif_speed_ms.get())
            
            if not gif_path or not os.path.exists(gif_path):
                raise RuntimeError("GIF creation failed")

            # Check if editor is enabled
            if not self.use_editor.get():
                # Send directly without editor
                export_mode = self.export_mode.get()
                if export_mode == "Send to Anki":
                    ok = add_audio_to_gif_card(audio_path, gif_path, self.deck_name.get(), "")
                    if ok:
                        self.status.config(text=f"✅ MODE 4: Audio→GIF card sent to {self.deck_name.get()}",
                                           fg=self.colors['success'])
                    else:
                        self.status.config(text="⚠️ MODE 4: Anki not responding. Files saved to disk.",
                                           fg=self.colors['error'])
                elif export_mode == "Send to FlashLearn":
                    # Use auth-checked send - will open login if not authenticated
                    ok = self._send_to_flashlearn_with_auth(add_audio_to_gif_card_flashlearn, audio_path, gif_path, self.deck_name.get(), "")
                    if ok:
                        self.status.config(text=f"✅ MODE 4: Audio→GIF card sent to FlashLearn ({self.deck_name.get()})",
                                           fg=self.colors['success'])
                    # If ok is None, login was triggered - status already updated
                else:
                    apkg_path = export_audio_to_gif_apkg(
                        audio_path, gif_path, self.deck_name.get(), self.apkg_gif_name.get()
                    )
                    if apkg_path:
                        self.status.config(text=f"✅ MODE 4: .apkg exported: {os.path.basename(apkg_path)}",
                                           fg=self.colors['success'])
                    else:
                        self.status.config(text="⚠️ MODE 4: Failed to export .apkg. Files saved to disk.",
                                           fg=self.colors['error'])
            else:
                # Show editor with GIF
                def on_gif_editor_done(confirmed, final_audio_path, final_media_paths, notes):
                    if not confirmed:
                        self.status.config(text="⚠️ MODE 4: Cancelled", fg=self.colors['error'])
                        return
                    
                    try:
                        export_mode = self.export_mode.get()
                        if export_mode == "Send to Anki":
                            ok = add_audio_to_gif_card(final_audio_path, gif_path, self.deck_name.get(), notes)
                            if ok:
                                self.status.config(
                                    text=f"✅ MODE 4: Audio→GIF card sent to {self.deck_name.get()}",
                                    fg=self.colors['success']
                                )
                            else:
                                self.status.config(
                                    text="⚠️ MODE 4: Anki not responding. Files saved to disk.",
                                    fg=self.colors['error']
                                )
                        elif export_mode == "Send to FlashLearn":
                            # Use auth-checked send - will open login if not authenticated
                            ok = self._send_to_flashlearn_with_auth(add_audio_to_gif_card_flashlearn, final_audio_path, gif_path, self.deck_name.get(), notes)
                            if ok:
                                self.status.config(
                                    text=f"✅ MODE 4: Audio→GIF card sent to FlashLearn ({self.deck_name.get()})",
                                    fg=self.colors['success']
                                )
                            # If ok is None, login was triggered - status already updated
                        else:
                            apkg_path = export_audio_to_gif_apkg(
                                final_audio_path, gif_path, self.deck_name.get(), 
                                self.apkg_gif_name.get()
                            )
                            if apkg_path:
                                self.status.config(
                                    text=f"✅ MODE 4: .apkg exported: {os.path.basename(apkg_path)}",
                                    fg=self.colors['success']
                                )
                            else:
                                self.status.config(
                                    text="⚠️ MODE 4: Failed to export .apkg. Files saved to disk.",
                                    fg=self.colors['error']
                                )
                    except Exception as e:
                        logger.error(f"MODE 4 send failed: {e}", exc_info=True)
                        self.status.config(text=f"❌ MODE 4 Error: {str(e)}", fg=self.colors['error'])
                
                # Show editor in embedded panel
                self._show_embedded_editor(
                    audio_path=audio_path,
                    image_paths=None,
                    gif_path=gif_path,
                    mode_name="MODE 4: Audio→GIF",
                    send_func=add_audio_to_gif_card,
                    export_func=export_audio_to_gif_apkg
                )

        except Exception as e:
            logger.error(f"MODE 4 failed: {e}", exc_info=True)
            self.status.config(text=f"❌ MODE 4 Error: {str(e)}", fg=self.colors['error'])
            self.show_error("MODE 4 Failed", f"Failed to capture Audio→GIF:\n\n{str(e)}")

    def _capture_audio_to_screenshots(self):
        """MODE 5: Audio front → Multiple Screenshots back (1 card)"""
        try:
            logger.info("MODE 5: Capturing Audio->Screenshots")
            self.status.config(text="📸 MODE 5: Creating audio and screenshots...", fg=self.colors['accent'])

            total_duration = float(self.seconds.get())
            before_seconds = float(self.audio_before_seconds.get())
            if before_seconds < 0:
                before_seconds = 0.0
            if before_seconds > total_duration:
                before_seconds = total_duration
            after_seconds = total_duration - before_seconds

            logger.info(f"Waiting {after_seconds}s before capturing...")
            
            # Wait for the 'after' period (like audio capture)
            time.sleep(after_seconds)

            # Get audio from buffer (last N seconds)
            audio = self.rbuf.get_last_seconds(total_duration)
            
            if audio is None or len(audio) == 0:
                raise RuntimeError("No audio captured")

            # Get frames from rolling screenshot buffer (last N seconds)
            frames = self.screenshotter.get_frames_for_duration(total_duration)
            
            if not frames or len(frames) == 0:
                raise RuntimeError("No frames captured for screenshots")

            # Save audio
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            audio_path = os.path.join(SAVE_DIR, f"audio_{timestamp}.wav")
            write_wav_fast(audio_path, audio, SAMPLE_RATE)
            logger.info(f"Audio saved: {audio_path}")

            # Save all frames as individual screenshots
            screenshot_paths = []
            for i, frame in enumerate(frames):
                screenshot_path = os.path.join(SAVE_DIR, f"screenshot_{timestamp}_{i:03d}.png")
                frame.save(screenshot_path, "PNG")
                screenshot_paths.append(screenshot_path)
            
            logger.info(f"Saved {len(screenshot_paths)} screenshots")

            # Show editor in embedded panel
            self._show_embedded_editor(
                audio_path=audio_path,
                image_paths=screenshot_paths,
                mode_name="MODE 5: Audio→Screenshots",
                send_func=add_audio_to_screenshots_card,
                export_func=export_audio_to_screenshots_apkg
            )

        except Exception as e:
            logger.error(f"MODE 5 failed: {e}", exc_info=True)
            self.status.config(text=f"❌ MODE 5 Error: {str(e)}", fg=self.colors['error'])
            self.show_error("MODE 5 Failed", f"Failed to capture Audio→Screenshots:\n\n{str(e)}")

    def _hotkey_loop(self):
        """Background thread that listens for hotkeys"""
        logger.info("Hotkey listener started")
        try:
            while True:
                try:
                    # Skip hotkey detection if we're capturing a new hotkey
                    if self.capturing_hotkey:
                        time.sleep(0.1)
                        continue
                        
                    if self.keyboard.is_pressed(self.hotkey_audio_to_image.get()):
                        threading.Thread(target=self._capture_audio_to_image, daemon=True).start()
                        time.sleep(0.5)
                    elif self.keyboard.is_pressed(self.hotkey_image_to_audio.get()):
                        threading.Thread(target=self._capture_image_to_audio, daemon=True).start()
                        time.sleep(0.5)
                    elif self.keyboard.is_pressed(self.hotkey_both_directions.get()):
                        threading.Thread(target=self._capture_both_directions, daemon=True).start()
                        time.sleep(0.5)
                    elif self.keyboard.is_pressed(self.hotkey_audio_to_video.get()):
                        threading.Thread(target=self._capture_audio_to_gif, daemon=True).start()
                        time.sleep(0.5)
                    time.sleep(0.05)
                except Exception as e:
                    logger.error(f"Error in hotkey check: {e}")
                    time.sleep(0.1)
        except Exception as e:
            logger.error(f"Hotkey loop crashed: {e}", exc_info=True)

    def _update_status(self):
        buf_sec = self.rbuf.frames / SAMPLE_RATE
        before = self.audio_before_seconds.get()
        after = self.seconds.get() - before
        self.status.config(
            text=f"🎙️ Buffer: {buf_sec:.1f}s | 📚 Deck: {self.deck_name.get()} | "
                 f"⏱️ {before:.1f}s before / {after:.1f}s after | "
                 f"Hotkeys: [{self.hotkey_audio_to_image.get().upper()}] "
                 f"[{self.hotkey_image_to_audio.get().upper()}] "
                 f"[{self.hotkey_both_directions.get().upper()}] "
                 f"[{self.hotkey_audio_to_video.get().upper()}]"
        )
        self.root.after(500, self._update_status)


    def on_closing(self):
        self.root.withdraw()
        self.is_minimized = True
        if not self.tray_icon:
            self.create_tray_icon()

    def create_tray_icon(self):
        icon_image = Image.new('RGB', (64, 64), color='#89b4fa')
        menu = pystray.Menu(
            item('Show', self.show_window),
            item('Mode 1: Audio→Image',
                 lambda: threading.Thread(target=self._capture_audio_to_image, daemon=True).start()),
            item('Mode 2: Image→Audio',
                 lambda: threading.Thread(target=self._capture_image_to_audio, daemon=True).start()),
            item('Mode 3: Both Directions',
                 lambda: threading.Thread(target=self._capture_both_directions, daemon=True).start()),
            item('Mode 4: Audio→GIF',
                 lambda: threading.Thread(target=self._capture_audio_to_gif, daemon=True).start()),
            item('Exit', self.quit_app)
        )
        self.tray_icon = pystray.Icon("anki_capture", icon_image, "Anki Capture Studio", menu)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

    def show_window(self):
        self.root.deiconify()
        self.root.lift()

    def quit_app(self):
        self.save_settings()
        self.rec.stop()
        self.screenshotter.stop()
        if self.tray_icon:
            self.tray_icon.stop()
        self.root.quit()
        sys.exit(0)


if __name__ == "__main__":
    try:
        logger.info("Starting main application")
        root = tk.Tk()
        app = App(root)
        root.mainloop()
    except Exception as e:
        logger.critical(f"Fatal error in main: {e}", exc_info=True)
        try:
            messagebox.showerror("Fatal Error",
                                 f"A critical error occurred:\n\n{str(e)}\n\n"
                                 "The application will now close.")
        except:
            print(f"FATAL ERROR: {e}")
        sys.exit(1)
