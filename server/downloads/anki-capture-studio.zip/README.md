# Anki Capture Studio

A powerful desktop application for creating Anki flashcards from audio recordings and screenshots.

## Features

- **Audio Capture**: Record audio from any application in real-time using a rolling buffer
- **Screenshot Capture**: Take screenshots with customizable screen regions
- **Hotkey Support**: Create flashcards instantly with keyboard shortcuts
- **Multiple Card Types**: 
  - Audio → Image (question is audio, answer is screenshot)
  - Image → Audio (question is screenshot, answer is audio)
  - Audio → Screenshots (multiple screenshots as answer)
  - Audio → GIF (animated screenshot)
- **Anki Integration**: Export directly to Anki deck format (.apkg)
- **System Tray**: Runs in the background with minimal resource usage

## Requirements

- Python 3.8 or higher
- pip (Python package manager)
- Working audio output device

## Installation

### Windows

1. Extract the ZIP file to a folder
2. Open Command Prompt or PowerShell in the extracted folder
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the application:
   ```bash
   python src/main.py
   ```

### macOS

1. Extract the ZIP file to a folder
2. Open Terminal in the extracted folder
3. Install dependencies:
   ```bash
   pip3 install -r requirements.txt
   ```
4. Run the application:
   ```bash
   python3 src/main.py
   ```
5. Grant necessary permissions for screen and audio capture when prompted

### Linux

1. Extract the ZIP file to a folder
2. Open a terminal in the extracted folder
3. Install system dependencies:
   ```bash
   sudo apt install python3-tk
   ```
4. Install Python dependencies:
   ```bash
   pip3 install -r requirements.txt
   ```
5. Run the application:
   ```bash
   python3 src/main.py
   ```

## Default Hotkeys

| Hotkey | Action |
|--------|--------|
| F8 | Audio → Screenshots |
| F9 | Audio → Image |
| F10 | Image → Audio |
| F11 | Both Directions |
| F12 | Audio → Video (GIF) |

All hotkeys can be customized in the application settings.

## Usage

1. Launch the application
2. Select your audio source (usually "Stereo Mix" or "What U Hear")
3. Set the recording duration (default: 5 seconds)
4. Select a screen region by clicking "Select Region"
5. Use the hotkeys to capture flashcards
6. Export your cards by clicking "Export to Anki"

## Output

Captured files are saved to: `~/Desktop/captures/`

- Audio files: `.wav` format
- Screenshots: `.png` format
- Anki decks: `.apkg` format

## Troubleshooting

### No audio devices found
- Ensure your audio drivers are installed
- On Windows, enable "Stereo Mix" in Sound settings
- On macOS, you may need an app like BlackHole for audio capture

### Hotkeys not working
- Make sure no other application is using the same hotkeys
- Try running the application as administrator (Windows)
- Check that the keyboard library has proper permissions

## License

MIT License

